const STYLES = {
  realistic: 'ultra realistic photograph, natural lighting, sharp focus, highly detailed, 8k',
  cinematic: 'cinematic still, dramatic lighting, anamorphic lens, film grain, color graded, epic composition',
  anime: 'anime style illustration, vibrant colors, clean line art, studio quality, detailed',
  '3d': '3D render, octane render, soft global illumination, high detail, stylized, subsurface scattering',
  fantasy: 'epic fantasy art, magical atmosphere, intricate details, glowing light, painterly, concept art',
  portrait: 'professional portrait photography, 85mm lens, shallow depth of field, soft studio lighting, detailed skin',
  professional: 'professional commercial photography, clean composition, studio lighting, high-end, polished'
};

const VIDEO_STYLES = {
  cinematic: 'cinematic camera movement, dramatic lighting, film look',
  realistic: 'realistic natural motion, handheld, documentary feel',
  anime: 'anime style animation, expressive motion',
  '3d': '3D animated, smooth motion, stylized render',
  fantasy: 'magical atmosphere, floating particles, epic fantasy motion',
  slowmo: 'slow motion, smooth, high frame detail',
  timelapse: 'timelapse, fast moving clouds and light'
};

const IMAGE_ASPECTS = ['1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3'];
const VIDEO_ASPECTS = ['9:16', '16:9', '1:1'];

function buildPrompt(prompt, style, table) {
  const s = table[style];
  return s ? `${prompt}, ${s}` : prompt;
}

// Most FLUX-class models have no negative prompt field; fold it into the text.
function withNegative(prompt, negative) {
  return negative ? `${prompt}. Avoid: ${negative}.` : prompt;
}

class ProviderError extends Error {
  constructor(msg, detail) { super(msg); this.detail = detail; }
}

async function http(url, opts = {}) {
  const res = await fetch(url, opts);
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* not json */ }
  if (!res.ok) {
    const msg = (json && (json.detail || json.error || json.message)) || text.slice(0, 300) || res.statusText;
    throw new ProviderError(`Provider error ${res.status}: ${typeof msg === 'string' ? msg : JSON.stringify(msg)}`, text.slice(0, 2000));
  }
  return json;
}

module.exports = { STYLES, VIDEO_STYLES, IMAGE_ASPECTS, VIDEO_ASPECTS, buildPrompt, withNegative, ProviderError, http };
