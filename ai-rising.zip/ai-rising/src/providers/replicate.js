const config = require('../config');
const { http, ProviderError } = require('./common');

const API = 'https://api.replicate.com/v1';
const headers = () => ({ Authorization: `Bearer ${config.replicateToken}`, 'Content-Type': 'application/json' });

function ready() { return !!config.replicateToken; }

// Map our normalized params -> model-specific inputs.
// If you switch to a different model slug, adjust the matching branch here.
function buildInput(type, p) {
  switch (type) {
    case 'text2img':
      return { prompt: p.prompt, aspect_ratio: p.aspect, num_outputs: 1, output_format: 'png', output_quality: 100 };
    case 'img2img':
      return { prompt: p.prompt, image: p.imageUrl, prompt_strength: p.strength ?? 0.75, aspect_ratio: p.aspect === 'match' ? 'match_input_image' : p.aspect, num_outputs: 1, output_format: 'png', output_quality: 100 };
    case 'text2video':
      return { prompt: p.prompt, duration: p.duration || 5, aspect_ratio: p.aspect, resolution: '720p' };
    case 'img2video': // aspect ratio follows the input image for this model
      return { prompt: p.prompt, image: p.imageUrl, duration: p.duration || 5, resolution: '720p' };
    case 'removebg':
      return { image: p.imageUrl };
    case 'upscale':
      return { image: p.imageUrl, scale: p.scale || 4, face_enhance: false };
    case 'enhance':
      return { image: p.imageUrl, scale: 2, face_enhance: true };
    default:
      throw new ProviderError(`Unsupported generation type: ${type}`);
  }
}

async function submit(type, params) {
  if (!ready()) throw new ProviderError('Replicate is not configured. Set REPLICATE_API_TOKEN on the server.');
  const model = config.models.replicate[type];
  const body = { input: buildInput(type, params) };
  const url = model.includes(':')
    ? `${API}/predictions`
    : `${API}/models/${model}/predictions`;
  if (model.includes(':')) body.version = model.split(':')[1];
  const r = await http(url, { method: 'POST', headers: headers(), body: JSON.stringify(body) });
  return { jobId: r.id, model };
}

function firstUrl(output) {
  if (!output) return null;
  if (typeof output === 'string') return output;
  if (Array.isArray(output)) return firstUrl(output[0]);
  if (typeof output === 'object') return output.url || output.image || output.video || output.output || null;
  return null;
}

async function poll(jobId) {
  const r = await http(`${API}/predictions/${jobId}`, { headers: headers() });
  if (r.status === 'succeeded') {
    const out = firstUrl(r.output);
    if (!out) throw new ProviderError('Provider finished but returned no output.');
    return { status: 'succeeded', progress: 100, outputUrl: out };
  }
  if (r.status === 'failed' || r.status === 'canceled') {
    return { status: 'failed', progress: 0, error: r.error || `Generation ${r.status}` };
  }
  // try to derive progress from logs (e.g. "45%|") else coarse stage
  let progress = r.status === 'starting' ? 8 : 35;
  const m = r.logs && [...r.logs.matchAll(/(\d{1,3})%/g)].pop();
  if (m) progress = Math.max(progress, Math.min(95, Number(m[1])));
  return { status: 'running', progress };
}

module.exports = { name: 'replicate', ready, submit, poll };
