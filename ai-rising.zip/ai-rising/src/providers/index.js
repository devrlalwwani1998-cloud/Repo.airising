const config = require('../config');
const providers = { replicate: require('./replicate'), fal: require('./fal') };

function active() {
  const p = providers[config.provider];
  if (!p) throw new Error(`Unknown AI_PROVIDER "${config.provider}". Use replicate or fal.`);
  return p;
}

module.exports = { active, providers };
