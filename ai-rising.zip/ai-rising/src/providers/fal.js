const config = require('../config');
const { http, ProviderError } = require('./common');

const QUEUE = 'https://queue.fal.run';
const headers = () => ({ Authorization: `Key ${config.falKey}`, 'Content-Type': 'application/json' });

function ready() { return !!config.falKey; }

const IMG_SIZE = {
  '1:1': 'square_hd', '16:9': 'landscape_16_9', '9:16': 'portrait_16_9',
  '4:3': 'landscape_4_3', '3:4': 'portrait_4_3', '3:2': 'landscape_4_3', '2:3': 'portrait_4_3'
};

function buildInput(type, p) {
  switch (type) {
    case 'text2img':
      return { prompt: p.prompt, image_size: IMG_SIZE[p.aspect] || 'square_hd', num_images: 1, enable_safety_checker: true };
    case 'img2img':
      return { prompt: p.prompt, image_url: p.imageUrl, strength: p.strength ?? 0.85, num_images: 1, enable_safety_checker: true };
    case 'text2video':
      return { prompt: p.prompt, duration: String(p.duration || 5), aspect_ratio: p.aspect, resolution: '720p' };
    case 'img2video':
      return { prompt: p.prompt, image_url: p.imageUrl, duration: String(p.duration || 5), aspect_ratio: p.aspect, resolution: '720p' };
    case 'removebg':
      return { image_url: p.imageUrl };
    case 'upscale':
    case 'enhance':
      return { image_url: p.imageUrl, scale: type === 'enhance' ? 2 : (p.scale || 4) };
    default:
      throw new ProviderError(`Unsupported generation type: ${type}`);
  }
}

async function submit(type, params) {
  if (!ready()) throw new ProviderError('fal.ai is not configured. Set FAL_KEY on the server.');
  const model = config.models.fal[type];
  const r = await http(`${QUEUE}/${model}`, { method: 'POST', headers: headers(), body: JSON.stringify(buildInput(type, params)) });
  // fal returns the exact status/response URLs – store them as the job id
  return { jobId: JSON.stringify({ s: r.status_url, r: r.response_url }), model };
}

function extractUrl(o) {
  if (!o) return null;
  return (o.images && o.images[0] && o.images[0].url)
    || (o.image && o.image.url)
    || (o.video && o.video.url)
    || (o.output && o.output.url)
    || o.url || null;
}

async function poll(jobId) {
  const { s, r } = JSON.parse(jobId);
  const st = await http(s, { headers: headers() });
  if (st.status === 'COMPLETED') {
    const res = await http(r, { headers: headers() });
    const out = extractUrl(res);
    if (!out) throw new ProviderError('Provider finished but returned no output.', JSON.stringify(res).slice(0, 1500));
    return { status: 'succeeded', progress: 100, outputUrl: out };
  }
  if (st.status === 'IN_QUEUE') return { status: 'running', progress: 10 };
  if (st.status === 'IN_PROGRESS') return { status: 'running', progress: 50 };
  return { status: 'failed', progress: 0, error: st.error || `Unexpected status ${st.status}` };
}

module.exports = { name: 'fal', ready, submit, poll };
