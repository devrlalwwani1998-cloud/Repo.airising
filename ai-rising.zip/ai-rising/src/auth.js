const jwt = require('jsonwebtoken');
const config = require('./config');
const { db } = require('./db');

const COOKIE = 'ar_token';

function issue(res, user) {
  const token = jwt.sign({ uid: user.id }, config.jwtSecret, { expiresIn: '30d' });
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.isProd,
    maxAge: 30 * 24 * 3600 * 1000
  });
  return token;
}

function clear(res) { res.clearCookie(COOKIE); }

function load(req) {
  const h = req.headers.authorization;
  const token = (h && h.startsWith('Bearer ') ? h.slice(7) : null) || (req.cookies && req.cookies[COOKIE]);
  if (!token) return null;
  try {
    const { uid } = jwt.verify(token, config.jwtSecret);
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(uid);
    if (!u || u.disabled) return null;
    return u;
  } catch { return null; }
}

function optionalAuth(req, _res, next) { req.user = load(req); next(); }
function requireAuth(req, res, next) {
  const u = load(req);
  if (!u) return res.status(401).json({ error: 'Please log in to continue.' });
  req.user = u; next();
}
function requireAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' });
    next();
  });
}

function publicUser(u) {
  return {
    id: u.id, email: u.email, name: u.name, avatar: u.avatar,
    role: u.role, plan: u.plan, created_at: u.created_at,
    hasPassword: !!u.password_hash
  };
}

module.exports = { issue, clear, optionalAuth, requireAuth, requireAdmin, publicUser };
