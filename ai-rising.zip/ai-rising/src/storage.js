// Storage abstraction: local disk (dev) or S3-compatible cloud storage (prod).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const config = require('./config');

const cfg = config.storage;
let s3 = null, S3 = null;

if (cfg.driver === 's3') {
  S3 = require('@aws-sdk/client-s3');
  s3 = new S3.S3Client({
    region: cfg.region,
    endpoint: cfg.endpoint,
    forcePathStyle: !!cfg.endpoint,
    credentials: { accessKeyId: cfg.accessKeyId, secretAccessKey: cfg.secretAccessKey }
  });
} else {
  fs.mkdirSync(cfg.localDir, { recursive: true });
}

function makeKey(userId, ext) {
  const id = crypto.randomBytes(12).toString('hex');
  return `u${userId}/${new Date().toISOString().slice(0, 7)}/${id}${ext || ''}`;
}

function urlFor(key) {
  if (cfg.driver === 's3') {
    if (cfg.publicBaseUrl) return `${cfg.publicBaseUrl.replace(/\/$/, '')}/${key}`;
    const base = cfg.endpoint ? `${cfg.endpoint.replace(/\/$/, '')}/${cfg.bucket}` : `https://${cfg.bucket}.s3.${cfg.region}.amazonaws.com`;
    return `${base}/${key}`;
  }
  return `/files/${key}`;
}

async function put(key, buffer, mime) {
  if (cfg.driver === 's3') {
    await s3.send(new S3.PutObjectCommand({ Bucket: cfg.bucket, Key: key, Body: buffer, ContentType: mime }));
  } else {
    const full = path.join(cfg.localDir, key);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, buffer);
  }
  return { key, url: urlFor(key) };
}

async function remove(key) {
  try {
    if (cfg.driver === 's3') {
      await s3.send(new S3.DeleteObjectCommand({ Bucket: cfg.bucket, Key: key }));
    } else {
      const full = path.join(cfg.localDir, key);
      if (full.startsWith(cfg.localDir)) fs.rmSync(full, { force: true });
    }
  } catch (e) { console.warn('[storage] delete failed', key, e.message); }
}

async function getBuffer(key) {
  if (cfg.driver === 's3') {
    const r = await s3.send(new S3.GetObjectCommand({ Bucket: cfg.bucket, Key: key }));
    const chunks = [];
    for await (const c of r.Body) chunks.push(c);
    return Buffer.concat(chunks);
  }
  return fs.readFileSync(path.join(cfg.localDir, key));
}

// Absolute URL a third-party AI provider can fetch (needs to be public). For local dev
// storage we fall back to a data URI, which both Replicate and fal accept for images.
async function providerUrl(media) {
  if (cfg.driver === 's3') return media.url;
  const buf = await getBuffer(media.storage_key);
  return `data:${media.mime || 'image/png'};base64,${buf.toString('base64')}`;
}

module.exports = { makeKey, put, remove, getBuffer, urlFor, providerUrl, driver: cfg.driver };
