// Orchestrates generation jobs: quota check, submit to provider, poll, store result.
const path = require('path');
const config = require('../config');
const { db, getSetting, logError } = require('../db');
const storage = require('../storage');
const providers = require('../providers');
const { STYLES, VIDEO_STYLES, IMAGE_ASPECTS, VIDEO_ASPECTS, buildPrompt, withNegative } = require('../providers/common');

const TYPES = ['text2img', 'img2img', 'text2video', 'img2video', 'removebg', 'upscale', 'enhance'];
const VIDEO_TYPES = ['text2video', 'img2video'];

function dailyLimitFor(user) {
  if (user.role === 'admin') return 100000;
  if (user.daily_limit != null) return user.daily_limit;
  const key = user.plan === 'premium' ? 'limit_premium' : 'limit_free';
  return Number(getSetting(key, user.plan === 'premium' ? config.limits.premium : config.limits.free));
}

function usedToday(userId) {
  return db.prepare(`SELECT COUNT(*) c FROM generations WHERE user_id=? AND status!='failed' AND date(created_at)=date('now')`).get(userId).c;
}

function quota(user) {
  const limit = dailyLimitFor(user);
  const used = usedToday(user.id);
  return { limit, used, remaining: Math.max(0, limit - used) };
}

function validate(type, body, media) {
  if (!TYPES.includes(type)) throw httpErr(400, 'Unknown generation type.');
  const isVideo = VIDEO_TYPES.includes(type);
  const needsPrompt = ['text2img', 'img2img', 'text2video'].includes(type);
  const needsImage = ['img2img', 'img2video', 'removebg', 'upscale', 'enhance'].includes(type);
  const prompt = String(body.prompt || '').trim();
  if (needsPrompt && prompt.length < 3) throw httpErr(400, 'Please enter a prompt (at least 3 characters).');
  if (prompt.length > 2000) throw httpErr(400, 'Prompt is too long (max 2000 characters).');
  if (needsImage && !media) throw httpErr(400, 'Please choose or upload an image first.');
  if (needsImage && media.kind !== 'image') throw httpErr(400, 'The selected file must be an image.');
  const aspects = isVideo ? VIDEO_ASPECTS : IMAGE_ASPECTS;
  const aspect = body.aspect || (isVideo ? '16:9' : '1:1');
  if (!aspects.includes(aspect) && !(type === 'img2img' && aspect === 'match')) throw httpErr(400, `Unsupported aspect ratio ${aspect}.`);
  const table = isVideo ? VIDEO_STYLES : STYLES;
  const style = body.style && table[body.style] ? body.style : null;
  let duration = null;
  if (isVideo) {
    duration = Number(body.duration || 5);
    if (![5, 8, 10].includes(duration)) duration = 5;
  }
  return { prompt, aspect, style, duration, negative: String(body.negative_prompt || '').trim().slice(0, 500) };
}

function httpErr(status, message) { const e = new Error(message); e.status = status; return e; }

async function start(user, type, body) {
  const input = body.media_id
    ? db.prepare('SELECT * FROM media WHERE id=? AND user_id=?').get(Number(body.media_id), user.id)
    : null;
  const v = validate(type, body, input);

  const q = quota(user);
  if (q.remaining <= 0) throw httpErr(429, `Daily limit reached (${q.limit} generations). Upgrade to Premium for more.`);

  const provider = providers.active();
  if (!provider.ready()) throw httpErr(503, 'AI generation is not configured on this server yet. The admin must add the provider API key.');

  const isVideo = VIDEO_TYPES.includes(type);
  const styled = ['removebg', 'upscale', 'enhance'].includes(type)
    ? ''
    : withNegative(buildPrompt(v.prompt, v.style, isVideo ? VIDEO_STYLES : STYLES), v.negative);
  const imageUrl = input ? await storage.providerUrl(input) : undefined;

  const ins = db.prepare(`INSERT INTO generations(user_id,type,provider,prompt,negative_prompt,style,aspect,duration,input_media_id,input_url,status,progress)
    VALUES(?,?,?,?,?,?,?,?,?,?, 'queued', 1)`)
    .run(user.id, type, provider.name, v.prompt, v.negative || null, v.style, v.aspect, v.duration, input ? input.id : null, input ? input.url : null);
  const genId = ins.lastInsertRowid;

  try {
    const { jobId, model } = await provider.submit(type, {
      prompt: styled, aspect: v.aspect, duration: v.duration, imageUrl,
      strength: body.strength ? Number(body.strength) : undefined, scale: body.scale ? Number(body.scale) : undefined
    });
    db.prepare(`UPDATE generations SET provider_job_id=?, model=?, status='running', progress=5 WHERE id=?`).run(jobId, model, genId);
  } catch (e) {
    fail(genId, e, user.id);
    throw httpErr(502, friendly(e));
  }
  return genId;
}

function friendly(e) {
  const m = String(e.message || e);
  if (/402|credit|billing|payment/i.test(m)) return 'The AI provider account is out of credit. Please contact the site admin.';
  if (/401|403|unauthor|invalid token|forbidden/i.test(m)) return 'The AI provider rejected the server credentials. Please contact the site admin.';
  if (/429|rate/i.test(m)) return 'The AI provider is busy right now. Please try again in a minute.';
  if (/nsfw|safety|flagged|sensitive/i.test(m)) return 'Your prompt or image was blocked by the safety filter. Please try something different.';
  return m.length > 220 ? m.slice(0, 220) + '…' : m;
}

function fail(genId, e, userId) {
  const msg = friendly(e);
  logError('generation', e.message || String(e), e.detail || e.stack, userId);
  db.prepare(`UPDATE generations SET status='failed', error=?, finished_at=datetime('now') WHERE id=?`).run(msg, genId);
}

const finalizing = new Set();

// Called whenever the client polls (and by the recovery sweep). Idempotent.
async function refresh(gen) {
  if (gen.status === 'succeeded' || gen.status === 'failed') return gen;
  if (!gen.provider_job_id) return gen;
  // time out jobs stuck > 15 min
  const age = (Date.now() - new Date(gen.created_at.replace(' ', 'T') + 'Z').getTime()) / 1000;
  if (age > 900) {
    fail(gen.id, new Error('Generation timed out. Please try again.'), gen.user_id);
    return db.prepare('SELECT * FROM generations WHERE id=?').get(gen.id);
  }
  if (finalizing.has(gen.id)) return gen;
  finalizing.add(gen.id);
  try {
    const provider = providers.providers[gen.provider];
    const r = await provider.poll(gen.provider_job_id);
    if (r.status === 'running') {
      db.prepare('UPDATE generations SET progress=MAX(progress,?) WHERE id=?').run(r.progress, gen.id);
    } else if (r.status === 'failed') {
      fail(gen.id, new Error(r.error || 'Generation failed'), gen.user_id);
    } else if (r.status === 'succeeded') {
      await saveOutput(gen, r.outputUrl);
    }
  } catch (e) {
    // transient poll errors shouldn't kill the job; only log
    logError('poll', e.message, e.detail, gen.user_id);
  } finally { finalizing.delete(gen.id); }
  return db.prepare('SELECT * FROM generations WHERE id=?').get(gen.id);
}

async function saveOutput(gen, outputUrl) {
  const isVideo = VIDEO_TYPES.includes(gen.type);
  try {
    const res = await fetch(outputUrl);
    if (!res.ok) throw new Error(`Could not download result (${res.status})`);
    const buf = Buffer.from(await res.arrayBuffer());
    const mime = (res.headers.get('content-type') || (isVideo ? 'video/mp4' : 'image/png')).split(';')[0];
    const ext = isVideo ? '.mp4' : (mime.includes('jpeg') ? '.jpg' : mime.includes('webp') ? '.webp' : '.png');
    const key = storage.makeKey(gen.user_id, ext);
    const put = await storage.put(key, buf, mime);
    const m = db.prepare(`INSERT INTO media(user_id,kind,source,storage_key,url,original_name,mime,size,generation_id,prompt,style)
      VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(gen.user_id, isVideo ? 'video' : 'image', 'generated', key, put.url,
        `ai-rising-${gen.id}${ext}`, mime, buf.length, gen.id, gen.prompt, gen.style);
    db.prepare(`UPDATE generations SET status='succeeded', progress=100, output_media_id=?, finished_at=datetime('now') WHERE id=?`)
      .run(m.lastInsertRowid, gen.id);
  } catch (e) {
    fail(gen.id, e, gen.user_id);
  }
}

// On boot, finish any jobs that were running when the server stopped.
function startSweeper() {
  setInterval(async () => {
    const rows = db.prepare(`SELECT * FROM generations WHERE status IN ('queued','running') AND created_at > datetime('now','-20 minutes')`).all();
    for (const g of rows) await refresh(g);
  }, 8000).unref();
}

module.exports = { start, refresh, quota, startSweeper, STYLES, VIDEO_STYLES, IMAGE_ASPECTS, VIDEO_ASPECTS, httpErr };
