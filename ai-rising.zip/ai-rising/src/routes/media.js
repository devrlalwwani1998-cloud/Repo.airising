const express = require('express');
const multer = require('multer');
const crypto = require('crypto');
const path = require('path');
const config = require('../config');
const { db, logError } = require('../db');
const auth = require('../auth');
const storage = require('../storage');

const router = express.Router();

const IMAGE_MIMES = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif' };
const VIDEO_MIMES = { 'video/mp4': '.mp4', 'video/webm': '.webm', 'video/quicktime': '.mov' };
const MAX_IMAGE = 20 * 1024 * 1024;
const MAX_VIDEO = config.limits.maxUploadMb * 1024 * 1024;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_VIDEO, files: 12 }
});

// Check real file signature, not only the client-declared type.
function sniff(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf.slice(1, 4).toString() === 'PNG') return 'image/png';
  if (buf.slice(0, 3).toString() === 'GIF') return 'image/gif';
  if (buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return 'image/webp';
  if (buf.slice(4, 8).toString() === 'ftyp') return buf.slice(8, 12).toString().startsWith('qt') ? 'video/quicktime' : 'video/mp4';
  if (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return 'video/webm';
  return null;
}

const shape = m => ({
  id: m.id, kind: m.kind, source: m.source, url: m.url, name: m.original_name, mime: m.mime, size: m.size,
  folder_id: m.folder_id, favorite: !!m.favorite, is_public: !!m.is_public, share_token: m.share_token,
  prompt: m.prompt, style: m.style, created_at: m.created_at, generation_id: m.generation_id
});

// ---- Upload (multiple files, drag & drop, phone camera roll) ----
router.post('/upload', auth.requireAuth, (req, res) => {
  upload.array('files', 12)(req, res, async err => {
    if (err) {
      const msg = err.code === 'LIMIT_FILE_SIZE' ? `File too large (max ${config.limits.maxUploadMb} MB for video, 20 MB for images).`
        : err.code === 'LIMIT_FILE_COUNT' ? 'Too many files at once (max 12).' : 'Upload failed.';
      return res.status(400).json({ error: msg });
    }
    const files = req.files || [];
    if (!files.length) return res.status(400).json({ error: 'No files received.' });
    let folderId = req.body.folder_id ? Number(req.body.folder_id) : null;
    if (folderId && !db.prepare('SELECT 1 FROM folders WHERE id=? AND user_id=?').get(folderId, req.user.id)) folderId = null;

    const saved = [], rejected = [];
    for (const f of files) {
      try {
        const real = sniff(f.buffer);
        const isImg = real && IMAGE_MIMES[real], isVid = real && VIDEO_MIMES[real];
        if (!isImg && !isVid) { rejected.push({ name: f.originalname, reason: 'Unsupported format (use JPG, PNG, WEBP, GIF, MP4, WEBM or MOV).' }); continue; }
        if (isImg && f.size > MAX_IMAGE) { rejected.push({ name: f.originalname, reason: 'Image larger than 20 MB.' }); continue; }
        const ext = isImg ? IMAGE_MIMES[real] : VIDEO_MIMES[real];
        const key = storage.makeKey(req.user.id, ext);
        const put = await storage.put(key, f.buffer, real);
        const name = path.basename(Buffer.from(f.originalname, 'latin1').toString('utf8')).slice(0, 120);
        const r = db.prepare(`INSERT INTO media(user_id,kind,source,storage_key,url,original_name,mime,size,folder_id)
          VALUES(?,?,?,?,?,?,?,?,?)`).run(req.user.id, isImg ? 'image' : 'video', 'upload', key, put.url, name, real, f.size, folderId);
        saved.push(shape(db.prepare('SELECT * FROM media WHERE id=?').get(r.lastInsertRowid)));
      } catch (e) {
        logError('upload', e.message, e.stack, req.user.id);
        rejected.push({ name: f.originalname, reason: 'Could not store this file.' });
      }
    }
    res.status(saved.length ? 200 : 400).json({ saved, rejected, error: saved.length ? undefined : 'No files could be uploaded.' });
  });
});

// ---- List with filters ----
router.get('/', auth.requireAuth, (req, res) => {
  const { source, kind, folder, favorite, q } = req.query;
  const where = ['user_id=?'], args = [req.user.id];
  if (source === 'upload' || source === 'generated') { where.push('source=?'); args.push(source); }
  if (kind === 'image' || kind === 'video') { where.push('kind=?'); args.push(kind); }
  if (folder === 'none') where.push('folder_id IS NULL');
  else if (folder) { where.push('folder_id=?'); args.push(Number(folder)); }
  if (favorite === '1') where.push('favorite=1');
  if (q) { where.push('(prompt LIKE ? OR original_name LIKE ?)'); args.push(`%${q}%`, `%${q}%`); }
  const limit = Math.min(Number(req.query.limit) || 60, 200);
  const offset = Number(req.query.offset) || 0;
  const rows = db.prepare(`SELECT * FROM media WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`).all(...args, limit, offset);
  res.json({ items: rows.map(shape) });
});

// ---- Public: trending community creations ----
router.get('/trending', (_req, res) => {
  const rows = db.prepare(`SELECT m.*, u.name AS author FROM media m JOIN users u ON u.id=m.user_id
    WHERE m.is_public=1 AND m.source='generated' ORDER BY m.id DESC LIMIT 24`).all();
  res.json({ items: rows.map(r => ({ ...shape(r), author: r.author, share_token: undefined })) });
});

router.get('/download-history', auth.requireAuth, (req, res) => {
  const rows = db.prepare(`SELECT d.id AS dl_id, d.created_at AS downloaded_at, m.* FROM downloads d JOIN media m ON m.id=d.media_id
    WHERE d.user_id=? ORDER BY d.id DESC LIMIT 100`).all(req.user.id);
  res.json({ items: rows.map(r => ({ ...shape(r), downloaded_at: r.downloaded_at })) });
});

// ---- Folders ----
router.get('/folders', auth.requireAuth, (req, res) => {
  res.json({ folders: db.prepare(`SELECT f.id, f.name, (SELECT COUNT(*) FROM media m WHERE m.folder_id=f.id) AS count
    FROM folders f WHERE f.user_id=? ORDER BY f.name`).all(req.user.id) });
});
router.post('/folders', auth.requireAuth, (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 40);
  if (!name) return res.status(400).json({ error: 'Folder name is required.' });
  if (db.prepare('SELECT COUNT(*) c FROM folders WHERE user_id=?').get(req.user.id).c >= 50) return res.status(400).json({ error: 'Folder limit reached (50).' });
  const r = db.prepare('INSERT INTO folders(user_id,name) VALUES(?,?)').run(req.user.id, name);
  res.json({ folder: { id: r.lastInsertRowid, name, count: 0 } });
});
router.patch('/folders/:id', auth.requireAuth, (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 40);
  if (!name) return res.status(400).json({ error: 'Folder name is required.' });
  db.prepare('UPDATE folders SET name=? WHERE id=? AND user_id=?').run(name, req.params.id, req.user.id);
  res.json({ ok: true });
});
router.delete('/folders/:id', auth.requireAuth, (req, res) => {
  db.prepare('DELETE FROM folders WHERE id=? AND user_id=?').run(req.params.id, req.user.id); // media.folder_id -> NULL
  res.json({ ok: true });
});

// ---- Single item actions ----
function own(req, res) {
  const m = db.prepare('SELECT * FROM media WHERE id=? AND user_id=?').get(Number(req.params.id), req.user.id);
  if (!m) { res.status(404).json({ error: 'File not found.' }); return null; }
  return m;
}

router.patch('/:id', auth.requireAuth, (req, res) => {
  const m = own(req, res); if (!m) return;
  const b = req.body;
  if (b.favorite != null) db.prepare('UPDATE media SET favorite=? WHERE id=?').run(b.favorite ? 1 : 0, m.id);
  if (b.is_public != null) db.prepare('UPDATE media SET is_public=? WHERE id=?').run(b.is_public ? 1 : 0, m.id);
  if (b.folder_id !== undefined) {
    const fid = b.folder_id ? Number(b.folder_id) : null;
    if (fid && !db.prepare('SELECT 1 FROM folders WHERE id=? AND user_id=?').get(fid, req.user.id)) return res.status(400).json({ error: 'Folder not found.' });
    db.prepare('UPDATE media SET folder_id=? WHERE id=?').run(fid, m.id);
  }
  if (b.name) db.prepare('UPDATE media SET original_name=? WHERE id=?').run(String(b.name).slice(0, 120), m.id);
  res.json({ item: shape(db.prepare('SELECT * FROM media WHERE id=?').get(m.id)) });
});

router.delete('/:id', auth.requireAuth, async (req, res) => {
  const m = own(req, res); if (!m) return;
  await storage.remove(m.storage_key);
  db.prepare('DELETE FROM downloads WHERE media_id=?').run(m.id);
  db.prepare('DELETE FROM media WHERE id=?').run(m.id);
  res.json({ ok: true });
});

router.post('/:id/share', auth.requireAuth, (req, res) => {
  const m = own(req, res); if (!m) return;
  const token = m.share_token || crypto.randomBytes(9).toString('base64url');
  db.prepare('UPDATE media SET share_token=? WHERE id=?').run(token, m.id);
  res.json({ link: `${config.publicUrl}/#/share/${token}`, token });
});
router.delete('/:id/share', auth.requireAuth, (req, res) => {
  const m = own(req, res); if (!m) return;
  db.prepare('UPDATE media SET share_token=NULL WHERE id=?').run(m.id);
  res.json({ ok: true });
});

// Download (HD original / MP4), logged to download history
router.get('/:id/download', auth.requireAuth, async (req, res) => {
  const m = own(req, res); if (!m) return;
  try {
    const buf = await storage.getBuffer(m.storage_key);
    db.prepare('INSERT INTO downloads(user_id,media_id) VALUES(?,?)').run(req.user.id, m.id);
    const fallback = `ai-rising-${m.id}${m.kind === 'video' ? '.mp4' : '.png'}`;
    res.setHeader('Content-Type', m.mime || 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${(m.original_name || fallback).replace(/[^\w.\- ]/g, '_')}"`);
    res.send(buf);
  } catch (e) {
    logError('download', e.message, e.stack, req.user.id);
    res.status(500).json({ error: 'Could not download this file.' });
  }
});

// Public share lookup (no auth)
router.get('/shared/:token', (req, res) => {
  const m = db.prepare(`SELECT m.*, u.name AS author FROM media m JOIN users u ON u.id=m.user_id WHERE m.share_token=?`).get(req.params.token);
  if (!m) return res.status(404).json({ error: 'This link is no longer available.' });
  res.json({ item: { kind: m.kind, url: m.url, prompt: m.prompt, style: m.style, author: m.author, created_at: m.created_at } });
});

// Single item (own) – keep this LAST so it doesn't shadow the fixed GET routes above
router.get('/:id', auth.requireAuth, (req, res) => {
  const m = own(req, res); if (!m) return;
  res.json({ item: shape(m) });
});

module.exports = router;
