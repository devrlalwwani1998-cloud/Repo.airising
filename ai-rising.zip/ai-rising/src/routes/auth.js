const express = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const config = require('../config');
const { db, logError, getSetting } = require('../db');
const auth = require('../auth');
const gen = require('../services/generation');
const storage = require('../storage');

const router = express.Router();
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 40, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Try again later.' } });

let googleClient = null;
function google() {
  if (!googleClient) {
    const { OAuth2Client } = require('google-auth-library');
    googleClient = new OAuth2Client(config.googleClientId);
  }
  return googleClient;
}

function roleFor(email) {
  const first = db.prepare('SELECT COUNT(*) c FROM users').get().c === 0;
  return (config.adminEmail && email === config.adminEmail) || (first && !config.adminEmail) ? 'admin' : 'user';
}

router.get('/config', (_req, res) => {
  const providers = require('../providers');
  res.json({
    googleClientId: config.googleClientId || null,
    provider: config.provider,
    aiReady: providers.active().ready(),
    paymentLink: process.env.PAYMENT_LINK || null,
    limits: { free: Number(getSetting('limit_free', config.limits.free)), premium: Number(getSetting('limit_premium', config.limits.premium)) }
  });
});

router.post('/signup', limiter, (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 60);
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (name.length < 2) return res.status(400).json({ error: 'Please enter your name.' });
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.status(400).json({ error: 'Please enter a valid email.' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  if (db.prepare('SELECT 1 FROM users WHERE email=?').get(email)) return res.status(409).json({ error: 'An account with this email already exists. Try logging in.' });
  const hash = bcrypt.hashSync(password, 11);
  const r = db.prepare('INSERT INTO users(email,name,password_hash,role,last_login) VALUES(?,?,?,?,datetime(\'now\'))').run(email, name, hash, roleFor(email));
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(r.lastInsertRowid);
  auth.issue(res, user);
  res.json({ user: auth.publicUser(user), quota: gen.quota(user) });
});

router.post('/login', limiter, (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user || !user.password_hash || !bcrypt.compareSync(password, user.password_hash))
    return res.status(401).json({ error: 'Incorrect email or password.' });
  if (user.disabled) return res.status(403).json({ error: 'This account has been disabled.' });
  db.prepare("UPDATE users SET last_login=datetime('now') WHERE id=?").run(user.id);
  auth.issue(res, user);
  res.json({ user: auth.publicUser(user), quota: gen.quota(user) });
});

router.post('/google', limiter, async (req, res) => {
  if (!config.googleClientId) return res.status(503).json({ error: 'Google sign-in is not configured on this server.' });
  try {
    const ticket = await google().verifyIdToken({ idToken: String(req.body.credential || ''), audience: config.googleClientId });
    const p = ticket.getPayload();
    if (!p.email || !p.email_verified) return res.status(400).json({ error: 'Your Google email is not verified.' });
    const email = p.email.toLowerCase();
    let user = db.prepare('SELECT * FROM users WHERE google_id=? OR email=?').get(p.sub, email);
    if (!user) {
      const r = db.prepare('INSERT INTO users(email,name,google_id,avatar,role) VALUES(?,?,?,?,?)')
        .run(email, p.name || email.split('@')[0], p.sub, p.picture || null, roleFor(email));
      user = db.prepare('SELECT * FROM users WHERE id=?').get(r.lastInsertRowid);
    } else if (!user.google_id) {
      db.prepare('UPDATE users SET google_id=?, avatar=COALESCE(avatar,?) WHERE id=?').run(p.sub, p.picture || null, user.id);
      user = db.prepare('SELECT * FROM users WHERE id=?').get(user.id);
    }
    if (user.disabled) return res.status(403).json({ error: 'This account has been disabled.' });
    db.prepare("UPDATE users SET last_login=datetime('now') WHERE id=?").run(user.id);
    auth.issue(res, user);
    res.json({ user: auth.publicUser(user), quota: gen.quota(user) });
  } catch (e) {
    logError('google-auth', e.message, e.stack);
    res.status(401).json({ error: 'Google sign-in failed. Please try again.' });
  }
});

router.post('/logout', (_req, res) => { auth.clear(res); res.json({ ok: true }); });

router.get('/me', auth.optionalAuth, (req, res) => {
  if (!req.user) return res.json({ user: null });
  res.json({ user: auth.publicUser(req.user), quota: gen.quota(req.user) });
});

router.patch('/me', auth.requireAuth, (req, res) => {
  const name = req.body.name != null ? String(req.body.name).trim().slice(0, 60) : req.user.name;
  if (name.length < 2) return res.status(400).json({ error: 'Name is too short.' });
  db.prepare('UPDATE users SET name=? WHERE id=?').run(name, req.user.id);
  res.json({ user: auth.publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)) });
});

router.post('/password', auth.requireAuth, limiter, (req, res) => {
  const { current_password, new_password } = req.body;
  if (String(new_password || '').length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters.' });
  if (req.user.password_hash && !bcrypt.compareSync(String(current_password || ''), req.user.password_hash))
    return res.status(400).json({ error: 'Current password is incorrect.' });
  db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(bcrypt.hashSync(String(new_password), 11), req.user.id);
  res.json({ ok: true });
});

router.delete('/me', auth.requireAuth, async (req, res) => {
  const pw = String(req.body.password || '');
  if (req.user.password_hash && !bcrypt.compareSync(pw, req.user.password_hash))
    return res.status(400).json({ error: 'Password is incorrect.' });
  const files = db.prepare('SELECT storage_key FROM media WHERE user_id=?').all(req.user.id);
  for (const f of files) await storage.remove(f.storage_key);
  db.prepare('DELETE FROM users WHERE id=?').run(req.user.id);
  auth.clear(res);
  res.json({ ok: true });
});

module.exports = router;
