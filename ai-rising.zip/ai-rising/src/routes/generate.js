const express = require('express');
const rateLimit = require('express-rate-limit');
const { db } = require('../db');
const auth = require('../auth');
const gen = require('../services/generation');

const router = express.Router();
router.use(auth.requireAuth);
router.use(rateLimit({ windowMs: 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false, message: { error: 'Slow down a little – too many requests.' } }));

const mediaShape = m => m && ({ id: m.id, kind: m.kind, url: m.url, name: m.original_name, favorite: !!m.favorite, prompt: m.prompt, style: m.style, created_at: m.created_at });

function shape(g) {
  const out = g.output_media_id ? db.prepare('SELECT * FROM media WHERE id=?').get(g.output_media_id) : null;
  return {
    id: g.id, type: g.type, status: g.status, progress: g.progress, error: g.error,
    prompt: g.prompt, style: g.style, aspect: g.aspect, duration: g.duration, created_at: g.created_at,
    result: mediaShape(out)
  };
}

router.get('/options', (_req, res) => {
  res.json({
    imageStyles: Object.keys(gen.STYLES), videoStyles: Object.keys(gen.VIDEO_STYLES),
    imageAspects: gen.IMAGE_ASPECTS, videoAspects: gen.VIDEO_ASPECTS, durations: [5, 8, 10]
  });
});

router.get('/quota', (req, res) => res.json(gen.quota(req.user)));

// Start a job: type in text2img | img2img | text2video | img2video | removebg | upscale | enhance
router.post('/:type', async (req, res) => {
  try {
    const id = await gen.start(req.user, req.params.type, req.body || {});
    const g = db.prepare('SELECT * FROM generations WHERE id=?').get(id);
    res.status(202).json({ generation: shape(g), quota: gen.quota(req.user) });
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message || 'Generation failed.' });
  }
});

// Poll a job (also advances it)
router.get('/job/:id', async (req, res) => {
  let g = db.prepare('SELECT * FROM generations WHERE id=? AND user_id=?').get(Number(req.params.id), req.user.id);
  if (!g) return res.status(404).json({ error: 'Generation not found.' });
  g = await gen.refresh(g);
  res.json({ generation: shape(g), quota: gen.quota(req.user) });
});

router.get('/history/list', (req, res) => {
  const rows = db.prepare('SELECT * FROM generations WHERE user_id=? ORDER BY id DESC LIMIT 100').all(req.user.id);
  res.json({ items: rows.map(shape) });
});

module.exports = router;
