const express = require('express');
const config = require('../config');
const { db, getSetting, setSetting } = require('../db');
const auth = require('../auth');
const storage = require('../storage');
const providers = require('../providers');

const router = express.Router();
router.use(auth.requireAdmin);

router.get('/overview', (_req, res) => {
  const c = sql => db.prepare(sql).get().c;
  const byType = db.prepare(`SELECT type, COUNT(*) count FROM generations GROUP BY type ORDER BY count DESC`).all();
  const perDay = db.prepare(`SELECT date(created_at) day, COUNT(*) total, SUM(status='failed') failed FROM generations
    WHERE created_at > datetime('now','-14 days') GROUP BY day ORDER BY day`).all();
  let provider = { name: config.provider, configured: false };
  try { provider.configured = providers.active().ready(); } catch (e) { provider.error = e.message; }
  res.json({
    totals: {
      users: c('SELECT COUNT(*) c FROM users'),
      premium: c("SELECT COUNT(*) c FROM users WHERE plan='premium'"),
      media: c('SELECT COUNT(*) c FROM media'),
      storageBytes: db.prepare('SELECT COALESCE(SUM(size),0) s FROM media').get().s,
      generations: c('SELECT COUNT(*) c FROM generations'),
      generationsToday: c("SELECT COUNT(*) c FROM generations WHERE date(created_at)=date('now')"),
      failed: c("SELECT COUNT(*) c FROM generations WHERE status='failed'"),
      running: c("SELECT COUNT(*) c FROM generations WHERE status IN ('queued','running')"),
      errors24h: c("SELECT COUNT(*) c FROM error_log WHERE created_at > datetime('now','-1 day')")
    },
    byType, perDay,
    system: {
      provider, storage: storage.driver, node: process.version, uptimeSec: Math.round(process.uptime()),
      googleAuth: !!config.googleClientId, models: config.models[config.provider],
      limits: { free: Number(getSetting('limit_free', config.limits.free)), premium: Number(getSetting('limit_premium', config.limits.premium)) }
    }
  });
});

// ---- Users ----
router.get('/users', (req, res) => {
  const q = `%${req.query.q || ''}%`;
  const rows = db.prepare(`SELECT u.id,u.email,u.name,u.role,u.plan,u.daily_limit,u.disabled,u.created_at,u.last_login,
      (SELECT COUNT(*) FROM generations g WHERE g.user_id=u.id) AS generations,
      (SELECT COUNT(*) FROM media m WHERE m.user_id=u.id) AS media
    FROM users u WHERE u.email LIKE ? OR u.name LIKE ? ORDER BY u.id DESC LIMIT 200`).all(q, q);
  res.json({ users: rows });
});
router.patch('/users/:id', (req, res) => {
  const id = Number(req.params.id);
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  if (!u) return res.status(404).json({ error: 'User not found.' });
  const b = req.body;
  if (id === req.user.id && (b.disabled || (b.role && b.role !== 'admin'))) return res.status(400).json({ error: "You can't disable or demote yourself." });
  if (b.plan && ['free', 'premium'].includes(b.plan)) db.prepare('UPDATE users SET plan=? WHERE id=?').run(b.plan, id);
  if (b.role && ['user', 'admin'].includes(b.role)) db.prepare('UPDATE users SET role=? WHERE id=?').run(b.role, id);
  if (b.disabled != null) db.prepare('UPDATE users SET disabled=? WHERE id=?').run(b.disabled ? 1 : 0, id);
  if (b.daily_limit !== undefined) db.prepare('UPDATE users SET daily_limit=? WHERE id=?').run(b.daily_limit === null || b.daily_limit === '' ? null : Number(b.daily_limit), id);
  res.json({ ok: true });
});
router.delete('/users/:id', async (req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) return res.status(400).json({ error: "You can't delete yourself." });
  for (const f of db.prepare('SELECT storage_key FROM media WHERE user_id=?').all(id)) await storage.remove(f.storage_key);
  db.prepare('DELETE FROM users WHERE id=?').run(id);
  res.json({ ok: true });
});

// ---- Media ----
router.get('/media', (req, res) => {
  const rows = db.prepare(`SELECT m.id,m.kind,m.source,m.url,m.size,m.created_at,m.prompt,u.email FROM media m JOIN users u ON u.id=m.user_id
    ORDER BY m.id DESC LIMIT ? OFFSET ?`).all(Math.min(Number(req.query.limit) || 60, 200), Number(req.query.offset) || 0);
  res.json({ items: rows });
});
router.delete('/media/:id', async (req, res) => {
  const m = db.prepare('SELECT * FROM media WHERE id=?').get(Number(req.params.id));
  if (!m) return res.status(404).json({ error: 'File not found.' });
  await storage.remove(m.storage_key);
  db.prepare('DELETE FROM downloads WHERE media_id=?').run(m.id);
  db.prepare('DELETE FROM media WHERE id=?').run(m.id);
  res.json({ ok: true });
});

// ---- Generation history / API usage ----
router.get('/generations', (req, res) => {
  const status = req.query.status;
  const rows = db.prepare(`SELECT g.id,g.type,g.provider,g.model,g.status,g.error,g.prompt,g.created_at,g.finished_at,u.email
    FROM generations g JOIN users u ON u.id=g.user_id ${status ? 'WHERE g.status=?' : ''} ORDER BY g.id DESC LIMIT 200`)
    .all(...(status ? [status] : []));
  res.json({ items: rows });
});
router.get('/usage', (_req, res) => {
  res.json({
    byProvider: db.prepare(`SELECT provider, model, type, COUNT(*) calls, SUM(status='succeeded') ok, SUM(status='failed') failed
      FROM generations GROUP BY provider, model, type ORDER BY calls DESC`).all(),
    topUsers: db.prepare(`SELECT u.email, COUNT(*) calls FROM generations g JOIN users u ON u.id=g.user_id
      WHERE g.created_at > datetime('now','-30 days') GROUP BY u.id ORDER BY calls DESC LIMIT 10`).all()
  });
});

// ---- Limits ----
router.get('/limits', (_req, res) => res.json({
  free: Number(getSetting('limit_free', config.limits.free)), premium: Number(getSetting('limit_premium', config.limits.premium))
}));
router.put('/limits', (req, res) => {
  const f = Number(req.body.free), p = Number(req.body.premium);
  if (!(f >= 0) || !(p >= 0)) return res.status(400).json({ error: 'Limits must be non-negative numbers.' });
  setSetting('limit_free', Math.floor(f)); setSetting('limit_premium', Math.floor(p));
  res.json({ ok: true });
});

// ---- Errors ----
router.get('/errors', (_req, res) => {
  res.json({ items: db.prepare('SELECT * FROM error_log ORDER BY id DESC LIMIT 200').all() });
});
router.delete('/errors', (_req, res) => { db.prepare('DELETE FROM error_log').run(); res.json({ ok: true }); });

module.exports = router;
