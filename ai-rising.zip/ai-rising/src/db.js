const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const config = require('./config');

fs.mkdirSync(config.dataDir, { recursive: true });
const db = new Database(path.join(config.dataDir, 'airising.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  password_hash TEXT,
  google_id TEXT UNIQUE,
  avatar TEXT,
  role TEXT NOT NULL DEFAULT 'user',        -- user | admin
  plan TEXT NOT NULL DEFAULT 'free',        -- free | premium
  daily_limit INTEGER,                      -- per-user override
  disabled INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_login TEXT
);
CREATE TABLE IF NOT EXISTS folders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
-- every file: uploads and generated results
CREATE TABLE IF NOT EXISTS media (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,                       -- image | video
  source TEXT NOT NULL,                     -- upload | generated
  storage_key TEXT NOT NULL,
  url TEXT NOT NULL,
  original_name TEXT,
  mime TEXT,
  size INTEGER,
  folder_id INTEGER REFERENCES folders(id) ON DELETE SET NULL,
  favorite INTEGER NOT NULL DEFAULT 0,
  is_public INTEGER NOT NULL DEFAULT 0,     -- shows in Trending / community
  share_token TEXT UNIQUE,
  generation_id INTEGER,
  prompt TEXT,
  style TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_media_user ON media(user_id, created_at);
CREATE TABLE IF NOT EXISTS generations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,                       -- text2img | img2img | text2video | img2video | removebg | upscale | enhance
  provider TEXT NOT NULL,
  model TEXT,
  prompt TEXT,
  negative_prompt TEXT,
  style TEXT,
  aspect TEXT,
  duration INTEGER,
  input_media_id INTEGER,
  input_url TEXT,
  provider_job_id TEXT,
  status TEXT NOT NULL DEFAULT 'queued',    -- queued | running | succeeded | failed
  progress INTEGER NOT NULL DEFAULT 0,
  error TEXT,
  output_media_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_gen_user ON generations(user_id, created_at);
CREATE TABLE IF NOT EXISTS downloads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  media_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS error_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT,
  message TEXT,
  detail TEXT,
  user_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);
`);

function getSetting(key, fallback) {
  const r = db.prepare('SELECT value FROM settings WHERE key=?').get(key);
  return r ? r.value : fallback;
}
function setSetting(key, value) {
  db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, String(value));
}
function logError(source, message, detail, userId) {
  try {
    db.prepare('INSERT INTO error_log(source,message,detail,user_id) VALUES(?,?,?,?)')
      .run(source, String(message).slice(0, 500), detail ? String(detail).slice(0, 4000) : null, userId || null);
  } catch (_) { /* never throw from logger */ }
}

module.exports = { db, getSetting, setSetting, logError };
