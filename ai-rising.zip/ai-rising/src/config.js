require('dotenv').config();
const crypto = require('crypto');
const path = require('path');

const env = process.env;
const isProd = env.NODE_ENV === 'production';

let jwtSecret = env.JWT_SECRET;
if (!jwtSecret || jwtSecret.startsWith('change-me')) {
  if (isProd) throw new Error('JWT_SECRET must be set in production');
  jwtSecret = crypto.randomBytes(32).toString('hex');
  console.warn('[config] JWT_SECRET not set – using a temporary one (sessions reset on restart)');
}

module.exports = {
  isProd,
  port: Number(env.PORT || 3000),
  publicUrl: env.PUBLIC_URL || `http://localhost:${env.PORT || 3000}`,
  jwtSecret,
  adminEmail: (env.ADMIN_EMAIL || '').toLowerCase(),
  provider: (env.AI_PROVIDER || 'replicate').toLowerCase(),
  replicateToken: env.REPLICATE_API_TOKEN || '',
  falKey: env.FAL_KEY || '',
  models: {
    replicate: {
      text2img: env.REPLICATE_MODEL_TEXT2IMG || 'black-forest-labs/flux-schnell',
      img2img: env.REPLICATE_MODEL_IMG2IMG || 'black-forest-labs/flux-dev',
      text2video: env.REPLICATE_MODEL_TEXT2VIDEO || 'bytedance/seedance-1-lite',
      img2video: env.REPLICATE_MODEL_IMG2VIDEO || 'bytedance/seedance-1-lite',
      removebg: env.REPLICATE_MODEL_REMOVE_BG || 'lucataco/remove-bg',
      upscale: env.REPLICATE_MODEL_UPSCALE || 'nightmareai/real-esrgan',
      enhance: env.REPLICATE_MODEL_ENHANCE || 'nightmareai/real-esrgan'
    },
    fal: {
      text2img: env.FAL_MODEL_TEXT2IMG || 'fal-ai/flux/schnell',
      img2img: env.FAL_MODEL_IMG2IMG || 'fal-ai/flux/dev/image-to-image',
      text2video: env.FAL_MODEL_TEXT2VIDEO || 'fal-ai/bytedance/seedance/v1/lite/text-to-video',
      img2video: env.FAL_MODEL_IMG2VIDEO || 'fal-ai/bytedance/seedance/v1/lite/image-to-video',
      removebg: env.FAL_MODEL_REMOVE_BG || 'fal-ai/imageutils/rembg',
      upscale: env.FAL_MODEL_UPSCALE || 'fal-ai/esrgan',
      enhance: env.FAL_MODEL_ENHANCE || 'fal-ai/esrgan'
    }
  },
  googleClientId: env.GOOGLE_CLIENT_ID || '',
  storage: {
    driver: (env.STORAGE_DRIVER || 'local').toLowerCase(),
    bucket: env.S3_BUCKET || '',
    region: env.S3_REGION || 'auto',
    endpoint: env.S3_ENDPOINT || undefined,
    accessKeyId: env.S3_ACCESS_KEY_ID || '',
    secretAccessKey: env.S3_SECRET_ACCESS_KEY || '',
    publicBaseUrl: env.S3_PUBLIC_BASE_URL || '',
    localDir: path.join(__dirname, '..', 'uploads')
  },
  limits: {
    free: Number(env.FREE_DAILY_LIMIT || 5),
    premium: Number(env.PREMIUM_DAILY_LIMIT || 100),
    maxUploadMb: Number(env.MAX_UPLOAD_MB || 100)
  },
  dataDir: path.join(__dirname, '..', 'data')
};
