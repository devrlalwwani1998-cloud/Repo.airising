const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const path = require('path');
const config = require('./config');
const { logError } = require('./db');
const storage = require('./storage');
const generation = require('./services/generation');

const app = express();
app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'script-src': ["'self'", 'https://accounts.google.com'],
      'img-src': ["'self'", 'data:', 'blob:', 'https:'],
      'media-src': ["'self'", 'blob:', 'https:'],
      'connect-src': ["'self'", 'https://accounts.google.com'],
      'frame-src': ['https://accounts.google.com'],
      'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://accounts.google.com'],
      'font-src': ["'self'", 'https://fonts.gstatic.com', 'data:'],
      'upgrade-insecure-requests': config.isProd ? [] : null
    }
  },
  crossOriginEmbedderPolicy: false,
  crossOriginResourcePolicy: { policy: 'cross-origin' }
}));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());

// Locally stored files (dev). In production use STORAGE_DRIVER=s3.
if (storage.driver === 'local') {
  app.use('/files', express.static(config.storage.localDir, { maxAge: '7d', index: false, dotfiles: 'deny' }));
}

app.get('/healthz', (_req, res) => res.json({ ok: true }));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/media', require('./routes/media'));
app.use('/api/generate', require('./routes/generate'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found.' }));

app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: config.isProd ? '1h' : 0 }));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, _next) => {
  logError('server', err.message, err.stack, req.user && req.user.id);
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid request.' });
  res.status(500).json({ error: 'Something went wrong on our side. Please try again.' });
});

process.on('unhandledRejection', e => logError('unhandledRejection', e && e.message, e && e.stack));

app.listen(config.port, () => {
  generation.startSweeper();
  console.log(`AI RISING running on ${config.publicUrl}  (provider=${config.provider}, storage=${storage.driver})`);
});
