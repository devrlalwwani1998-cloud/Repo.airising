/* Admin dashboard */
(function () {
  const { esc, icon, $ } = AR;
  const TABS = [['overview', 'Overview'], ['users', 'Users'], ['media', 'Media'], ['generations', 'Generations'], ['usage', 'API usage'], ['limits', 'Limits & plans'], ['errors', 'Errors & status']];
  const table = (head, rows) => `<div class="tbl-wrap"><table><thead><tr>${head.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('') || `<tr><td colspan="${head.length}" class="muted">Nothing to show.</td></tr>`}</tbody></table></div>`;
  const stat = (n, l) => `<div class="stat"><b>${n}</b><span>${l}</span></div>`;
  const stBadge = s => `<span class="badge ${s === 'succeeded' ? 'ok' : s === 'failed' ? 'err' : 'warn'}">${s}</span>`;
  const short = (s, n = 70) => esc((s || '').length > n ? s.slice(0, n) + '…' : s || '');

  const views = {
    async overview() {
      const d = await AR.api('/admin/overview'), t = d.totals, s = d.system;
      const max = Math.max(1, ...d.perDay.map(x => x.total));
      return `<div class="stats">${stat(t.users, 'Users')}${stat(t.premium, 'Premium users')}${stat(t.generationsToday, 'Generations today')}${stat(t.generations, 'Total generations')}
        ${stat(t.running, 'Running now')}${stat(t.failed, 'Failed (all time)')}${stat(t.media, 'Media files')}${stat(AR.fmtSize(t.storageBytes), 'Storage used')}</div>
        <div class="card" style="margin-top:14px"><h3>Generations – last 14 days</h3>
          <div class="mini-bars" style="margin-bottom:22px">${d.perDay.map(x => `<div style="height:${Math.max(3, x.total / max * 100)}%" title="${x.day}: ${x.total} (${x.failed || 0} failed)"><span>${x.day.slice(8)}</span></div>`).join('') || '<span class="muted">No data yet</span>'}</div></div>
        <div class="card" style="margin-top:14px"><h3>By type</h3>${d.byType.map(x => `<div class="row" style="justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line)"><span>${x.type}</span><b>${x.count}</b></div>`).join('') || '<p class="muted">No generations yet.</p>'}</div>`;
    },
    async users() {
      const d = await AR.api('/admin/users');
      return `<input class="input" id="usearch" placeholder="Search name or email…" style="margin-bottom:12px;max-width:340px">
        <div id="utable">${usersTable(d.users)}</div>`;
    },
    async media() {
      const d = await AR.api('/admin/media');
      return table(['Preview', 'User', 'Type', 'Size', 'Created', ''], d.items.map(m => `<tr>
        <td style="width:70px">${m.kind === 'video' ? `<video src="${esc(m.url)}#t=0.1" style="width:60px;height:60px;object-fit:cover;border-radius:8px" muted preload="metadata"></video>` : `<img src="${esc(m.url)}" style="width:60px;height:60px;object-fit:cover;border-radius:8px" loading="lazy" alt="">`}</td>
        <td>${esc(m.email)}</td><td>${m.kind} · ${m.source}</td><td>${AR.fmtSize(m.size || 0)}</td><td>${AR.fmtDate(m.created_at)}</td>
        <td><button class="btn sm danger" data-act="a-delmedia" data-id="${m.id}">Delete</button></td></tr>`));
    },
    async generations() {
      const d = await AR.api('/admin/generations');
      return table(['#', 'User', 'Type', 'Provider / model', 'Status', 'Prompt', 'Created'], d.items.map(g => `<tr><td>${g.id}</td><td>${esc(g.email)}</td><td>${g.type}</td>
        <td>${esc(g.provider)}<br><span class="muted" style="font-size:12px">${esc(g.model || '')}</span></td><td>${stBadge(g.status)}${g.error ? `<div class="muted" style="font-size:12px;max-width:220px">${short(g.error, 90)}</div>` : ''}</td>
        <td>${short(g.prompt)}</td><td>${AR.fmtDate(g.created_at)}</td></tr>`));
    },
    async usage() {
      const d = await AR.api('/admin/usage');
      return `<h3 style="margin-bottom:10px">By provider / model</h3>${table(['Provider', 'Model', 'Type', 'Calls', 'OK', 'Failed'], d.byProvider.map(r => `<tr><td>${esc(r.provider)}</td><td>${esc(r.model || '')}</td><td>${r.type}</td><td>${r.calls}</td><td>${r.ok || 0}</td><td>${r.failed || 0}</td></tr>`))}
        <h3 style="margin:22px 0 10px">Top users (30 days)</h3>${table(['User', 'Generations'], d.topUsers.map(u => `<tr><td>${esc(u.email)}</td><td>${u.calls}</td></tr>`))}
        <p class="muted" style="margin-top:12px;font-size:13px">Counts are calls made by this app. For exact spend, check your provider’s billing dashboard (Replicate / fal.ai).</p>`;
    },
    async limits() {
      const d = await AR.api('/admin/limits');
      return `<div class="card" style="max-width:480px"><h3>Daily generation limits</h3>
        <label class="f" for="lf">Free plan (per user / day)</label><input id="lf" type="number" min="0" class="input" value="${d.free}">
        <label class="f" for="lp">Premium plan (per user / day)</label><input id="lp" type="number" min="0" class="input" value="${d.premium}">
        <button class="btn primary" style="margin-top:14px" data-act="a-savelimits">Save limits</button></div>
        <p class="muted" style="margin-top:14px;font-size:13px">Subscriptions: switch a user between Free and Premium on the <b>Users</b> tab, or set a per-user daily limit override there. To take payments, set <code>PAYMENT_LINK</code> (e.g. a Stripe Payment Link) so the Upgrade button has somewhere to go, then promote the customer here.</p>`;
    },
    async errors() {
      const [o, e] = await Promise.all([AR.api('/admin/overview'), AR.api('/admin/errors')]), s = o.system;
      const ok = (v, y = 'OK', n = 'Not configured') => `<span class="badge ${v ? 'ok' : 'err'}">${v ? y : n}</span>`;
      return `<div class="card"><h3>System status</h3><div style="display:grid;gap:8px;margin-top:10px">
        <div class="row" style="justify-content:space-between"><span>AI provider (${esc(s.provider.name)})</span>${ok(s.provider.configured)}</div>
        <div class="row" style="justify-content:space-between"><span>Storage driver</span><span class="badge">${esc(s.storage)}</span></div>
        <div class="row" style="justify-content:space-between"><span>Google sign-in</span>${ok(s.googleAuth, 'Enabled', 'Disabled')}</div>
        <div class="row" style="justify-content:space-between"><span>Errors (24h)</span><span class="badge ${o.totals.errors24h ? 'warn' : 'ok'}">${o.totals.errors24h}</span></div>
        <div class="row" style="justify-content:space-between"><span>Node / uptime</span><span class="muted">${s.node} · ${Math.round(s.uptimeSec / 60)} min</span></div>
        <div style="margin-top:6px"><span class="muted" style="font-size:12.5px">Models in use:</span><div style="font-size:12.5px;margin-top:4px">${Object.entries(s.models).map(([k, v]) => `<div><b>${k}</b>: ${esc(v)}</div>`).join('')}</div></div></div></div>
        <div class="row" style="margin:20px 0 10px;justify-content:space-between"><h3>Error log</h3><button class="btn sm danger" data-act="a-clearerr">Clear log</button></div>
        ${table(['When', 'Source', 'Message', 'Detail'], e.items.map(x => `<tr><td style="white-space:nowrap">${AR.fmtDate(x.created_at)}</td><td>${esc(x.source)}</td><td>${short(x.message, 160)}</td><td><details><summary class="muted" style="cursor:pointer">view</summary><pre style="white-space:pre-wrap;font-size:11.5px;max-width:420px;overflow:auto">${esc(x.detail || '')}</pre></details></td></tr>`))}`;
    }
  };

  function usersTable(users) {
    return table(['User', 'Plan', 'Role', 'Limit', 'Gens', 'Files', 'Status', 'Actions'], users.map(u => `<tr>
      <td><b>${esc(u.name)}</b><br><span class="muted" style="font-size:12px">${esc(u.email)}</span></td>
      <td><select class="input" style="padding:6px" data-uf="plan" data-id="${u.id}"><option value="free" ${u.plan === 'free' ? 'selected' : ''}>Free</option><option value="premium" ${u.plan === 'premium' ? 'selected' : ''}>Premium</option></select></td>
      <td><select class="input" style="padding:6px" data-uf="role" data-id="${u.id}"><option value="user" ${u.role === 'user' ? 'selected' : ''}>User</option><option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option></select></td>
      <td><input class="input" style="padding:6px;width:80px" type="number" min="0" placeholder="plan" value="${u.daily_limit ?? ''}" data-uf="daily_limit" data-id="${u.id}" title="Per-user daily override (blank = plan default)"></td>
      <td>${u.generations}</td><td>${u.media}</td>
      <td>${u.disabled ? '<span class="badge err">Disabled</span>' : '<span class="badge ok">Active</span>'}<div class="muted" style="font-size:11.5px">Last: ${u.last_login ? AR.fmtDate(u.last_login) : '–'}</div></td>
      <td><div class="row" style="gap:6px"><button class="btn sm" data-act="a-toggle" data-id="${u.id}" data-d="${u.disabled ? 0 : 1}">${u.disabled ? 'Enable' : 'Disable'}</button><button class="btn sm danger" data-act="a-deluser" data-id="${u.id}">Delete</button></div></td></tr>`));
  }

  let current = 'overview';
  const show = async tab => {
    current = tab;
    $$tabs();
    const box = $('#abody'); box.innerHTML = '<div class="spinner"></div>';
    try {
      box.innerHTML = await views[tab]();
      if (tab === 'users') {
        let timer;
        $('#usearch').addEventListener('input', e => { clearTimeout(timer); timer = setTimeout(AR.safe(async () => { $('#utable').innerHTML = usersTable((await AR.api('/admin/users?q=' + encodeURIComponent(e.target.value))).users); }), 250); });
        $('#utable').addEventListener('change', AR.safe(async e => {
          const el = e.target.closest('[data-uf]'); if (!el) return;
          const body = { [el.dataset.uf]: el.dataset.uf === 'daily_limit' ? (el.value === '' ? null : Number(el.value)) : el.value };
          await AR.api('/admin/users/' + el.dataset.id, { method: 'PATCH', body }); AR.toast('Saved', 'ok');
        }));
      }
    } catch (e) { box.innerHTML = `<div class="alert err">${esc(e.message)}</div>`; }
  };
  const $$tabs = () => AR.$$('#atabs button').forEach(a => a.classList.toggle('on', a.dataset.t === current));

  const A = AR.acts;
  A['a-tab'] = t => show(t.dataset.t);
  A['a-toggle'] = async t => { await AR.api('/admin/users/' + t.dataset.id, { method: 'PATCH', body: { disabled: t.dataset.d === '1' } }); show('users'); };
  A['a-deluser'] = async t => { if (!confirm('Delete this user and all their files?')) return; await AR.api('/admin/users/' + t.dataset.id, { method: 'DELETE' }); show('users'); };
  A['a-delmedia'] = async t => { if (!confirm('Delete this file?')) return; await AR.api('/admin/media/' + t.dataset.id, { method: 'DELETE' }); show('media'); };
  A['a-savelimits'] = async () => { await AR.api('/admin/limits', { method: 'PUT', body: { free: $('#lf').value, premium: $('#lp').value } }); AR.toast('Limits saved', 'ok'); };
  A['a-clearerr'] = async () => { await AR.api('/admin/errors', { method: 'DELETE' }); show('errors'); };

  AR.pages['/admin'] = route => {
    current = TABS.some(t => t[0] === route.query.tab) ? route.query.tab : 'overview';
    AR.after = () => show(current);
    return `<h1 class="page-title">Admin <span class="grad-text">Dashboard</span></h1><p class="page-sub">Users, media, generation history, usage, limits and system health.</p>
      <div class="tabs" id="atabs">${TABS.map(([k, l]) => `<button type="button" data-act="a-tab" data-t="${k}" data-tab class="${k === current ? 'on' : ''}">${l}</button>`).join('')}</div>
      <div id="abody"></div>`;
  };
})();
