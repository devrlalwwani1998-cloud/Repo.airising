/* Home, AI Photo, AI Video */
(function () {
  const { esc, icon, $, $$ } = AR;

  AR.OPTS = {
    imageStyles: ['realistic', 'cinematic', 'anime', '3d', 'fantasy', 'portrait', 'professional'],
    videoStyles: ['cinematic', 'realistic', 'anime', '3d', 'fantasy', 'slowmo', 'timelapse'],
    imageAspects: ['1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3'],
    videoAspects: ['9:16', '16:9', '1:1'],
    durations: [5, 8, 10]
  };

  const IMG_IDEAS = [
    'A glowing jellyfish city floating above the clouds at sunrise',
    'Astronaut sitting on a neon-lit rooftop in the rain, reflections on wet ground',
    'A cozy wooden cabin in a snowy pine forest, warm light in the windows',
    'Portrait of a samurai with cherry blossoms drifting in the wind',
    'A futuristic electric car on a coastal road at golden hour',
    'Ancient dragon curled around a crystal mountain under the northern lights',
    'Street food market in Mumbai at night, steam and colorful lights',
    'Minimal product photo of a perfume bottle on black marble with purple light',
    'A tiny robot watering a garden of glowing flowers',
    'Underwater temple covered in bioluminescent coral'
  ];
  const VID_IDEAS = [
    'A drone flight over a misty mountain valley at sunrise',
    'Waves crashing on black volcanic rocks, slow motion, dramatic sky',
    'A neon cyberpunk street in the rain, cars passing, steam rising',
    'Cherry blossom petals swirling around a lone traveler on a bridge',
    'A hummingbird hovering near a glowing flower, macro shot',
    'Time-lapse of clouds rolling over a futuristic skyline at dusk',
    'A dragon flying through storm clouds, lightning flashing',
    'Camera slowly pushes in on a steaming cup of coffee by a rainy window'
  ];
  const IMG_FX = [['Neon glow', 'neon glow lighting, vivid cyberpunk colors'], ['Vintage film', 'vintage film photo, faded colors, film grain'], ['Oil painting', 'oil painting, visible brush strokes'], ['Watercolor', 'soft watercolor painting'], ['Dreamy', 'dreamy soft glow, pastel haze'], ['Dramatic B&W', 'dramatic black and white, high contrast'], ['Golden hour', 'warm golden hour sunlight']];
  const VID_FX = [['Zoom in', 'slow cinematic zoom in'], ['Camera pan', 'smooth camera pan'], ['Slow motion', 'slow motion'], ['Parallax', 'parallax depth movement'], ['Drone shot', 'aerial drone shot'], ['Time-lapse', 'time-lapse'], ['Handheld', 'handheld camera shake']];
  const pick = a => a[Math.floor(Math.random() * a.length)];
  const ideasRow = (arr, target) => [...arr].sort(() => Math.random() - 0.5).slice(0, 4)
    .map(p => `<button type="button" class="chip" data-act="idea" data-target="${target}" data-text="${esc(p)}" style="text-transform:none;text-align:left">${esc(p.length > 46 ? p.slice(0, 44) + '…' : p)}</button>`).join('');

  AR.acts.idea = t => { const ta = $('#' + t.dataset.target); if (ta) { ta.value = t.dataset.text; ta.dispatchEvent(new Event('input')); ta.focus(); } };
  AR.acts.surprise = t => { const ta = $('#' + t.dataset.target); const arr = t.dataset.kind === 'video' ? VID_IDEAS : IMG_IDEAS; ta.value = pick(arr); ta.dispatchEvent(new Event('input')); };

  /* ================= HOME ================= */
  AR.pages['/'] = () => {
    const u = AR.state.user;
    AR.after = async app => {
      AR.api('/media/trending').then(r => {
        AR.remember(r.items);
        $('#trend', app).innerHTML = r.items.length
          ? `<div class="grid">${r.items.slice(0, 8).map(m => AR.tile(m, { fav: false })).join('')}</div>`
          : `<div class="empty"><h3>Nothing trending yet</h3><p>Publish your best creations to Trending from My Creations and they'll show up here.</p></div>`;
      }).catch(() => { $('#trend', app).innerHTML = '<div class="empty">Could not load trending creations.</div>'; });
      if (u) {
        AR.api('/media?source=generated&limit=8').then(r => {
          AR.remember(r.items);
          $('#recent', app).innerHTML = r.items.length
            ? `<div class="grid">${r.items.map(m => AR.tile(m)).join('')}</div>`
            : `<div class="empty"><h3>No creations yet</h3><p>Describe an idea and press Generate – your results will appear here.</p><p style="margin-top:14px"><a class="btn primary" href="#/photo">Create your first photo</a></p></div>`;
        }).catch(() => {});
      }
    };
    const tools = [
      ['photo', 'Text → Image', 'Turn a description into a stunning image.', '/photo'],
      ['layers', 'Image → Image', 'Restyle or transform your own photos.', '/photo?mode=img2img'],
      ['video', 'Text → Video', 'Generate cinematic clips from a prompt.', '/video'],
      ['play', 'Image → Video', 'Bring any image to life with motion.', '/video?mode=img2video'],
      ['wand', 'Enhance', 'One-click sharpening and detail boost.', '/photo?mode=tools'],
      ['cut', 'Remove Background', 'Clean cut-outs in seconds.', '/photo?mode=tools'],
      ['expand', 'Upscale 4×', 'HD upscaling for print and posters.', '/photo?mode=tools'],
      ['gallery', 'Upload Gallery', 'Store, organize and reuse your media.', '/gallery']
    ];
    return `
    <section class="hero">
      <div class="eyebrow">${icon('sparkle')} Your Imagination. Powered by AI.</div>
      <h1>Create Amazing <span class="grad-text">AI Photos &amp; Videos</span></h1>
      <p>Generate images from text, transform your own photos, turn them into videos, and download everything in HD – all in one place.</p>
      <div class="cta">
        <a class="btn primary glow" href="#/gallery">${icon('upload')}Upload Your Image</a>
        <a class="btn" href="#/photo" style="border-color:rgba(139,92,246,.6)">${icon('sparkle')}Generate AI</a>
      </div>
    </section>
    <section class="sec"><div class="sec-head"><h2>Explore AI Tools</h2></div>
      <div class="tools">${tools.map(([ic, t, d, href]) => `<a class="tool" href="#${href}"><div class="ic">${icon(ic)}</div><h3>${t}</h3><p>${d}</p></a>`).join('')}</div></section>
    <section class="sec"><div class="sec-head"><h2>Trending AI Creations</h2></div><div id="trend"><div class="spinner"></div></div></section>
    <section class="sec"><div class="sec-head"><h2>${u ? 'Your Recent Creations' : 'Recent Creations'}</h2>${u ? '<a class="btn sm" href="#/creations">View all</a>' : ''}</div>
      <div id="recent">${u ? '<div class="spinner"></div>' : `<div class="empty"><h3>Sign up to start creating</h3><p>Free accounts include daily generations.</p><p style="margin-top:14px"><a class="btn primary" href="#/login?mode=signup">Create free account</a></p></div>`}</div></section>
    <section class="sec"><div class="sec-head"><h2>Need inspiration?</h2></div>
      <div class="chips">${[...IMG_IDEAS].sort(() => Math.random() - .5).slice(0, 5).map(p => `<a class="chip" style="text-transform:none" href="#/photo?prompt=${encodeURIComponent(p)}">${esc(p)}</a>`).join('')}</div></section>
    <footer class="foot"><b class="grad-text">AI RISING</b> – Create Beyond Imagination.</footer>`;
  };

  /* ================= shared generator helpers ================= */
  const chipRow = (name, vals, cur, fmt = v => v) => `<div class="chips" data-group="${name}">${vals.map(v => `<button type="button" class="chip ${String(v) === String(cur) ? 'on' : ''}" data-chip="${name}" data-v="${esc(v)}">${esc(fmt(v))}</button>`).join('')}</div>`;

  const refBox = S => `<div class="refbox" id="refbox">${S.ref
    ? `<img src="${esc(S.ref.url)}" alt="Reference"><div style="flex:1"><b>Reference image</b><div class="muted" style="font-size:12.5px">${esc(S.ref.name || 'Selected image')}</div></div><button type="button" class="btn sm" data-act="pickref">Change</button>`
    : `<div style="flex:1"><b>Reference image</b><div class="muted" style="font-size:12.5px">Upload from your phone/computer or choose from your gallery</div></div><button type="button" class="btn sm primary" data-act="pickref">${icon('upload')}Choose</button>`}</div>`;

  function previewShell(kind) {
    return `<div class="ph">${icon(kind === 'video' ? 'video' : 'photo')}<h3 style="margin-bottom:6px">Your ${kind} will appear here</h3><p>Write a prompt and press Generate.</p></div>`;
  }

  /* a generator page factory for photo & video */
  function makeGenerator(kind) {
    const isVid = kind === 'video';
    return route => {
      const q = route.query;
      const modes = isVid ? [['text2video', 'Text → Video'], ['img2video', 'Image → Video']] : [['text2img', 'Text → Image'], ['img2img', 'Image → Image'], ['tools', 'Tools']];
      const S = {
        mode: modes.some(m => m[0] === q.mode) ? q.mode : modes[0][0],
        prompt: q.prompt || '', neg: '', style: isVid ? 'cinematic' : 'realistic',
        aspect: isVid ? '16:9' : '1:1', duration: 5, ref: null, fx: new Set(), busy: false
      };
      const styles = isVid ? AR.OPTS.videoStyles : AR.OPTS.imageStyles;
      const fxList = isVid ? VID_FX : IMG_FX;
      const needsRef = S.mode === 'img2img' || S.mode === 'img2video' || S.mode === 'tools';

      const panelHtml = () => {
        const m = S.mode;
        const aspects = isVid ? AR.OPTS.videoAspects : (m === 'img2img' ? ['match', ...AR.OPTS.imageAspects] : AR.OPTS.imageAspects);
        const hasRef = m === 'img2img' || m === 'img2video' || m === 'tools';
        return `
        <div class="seg" role="tablist" style="width:100%;display:flex">${modes.map(([k, l]) => `<button type="button" style="flex:1" class="${S.mode === k ? 'on' : ''}" data-act="mode" data-m="${k}">${l}</button>`).join('')}</div>
        ${hasRef ? `<label class="f">${m === 'tools' ? 'Image to process' : 'Reference image'}</label>${refBox(S)}` : ''}
        ${m === 'tools' ? `
          <label class="f">One-click tools</label>
          <div style="display:grid;gap:8px">
            <button type="button" class="btn block" data-act="tool" data-t="enhance">${icon('wand')}Enhance image</button>
            <button type="button" class="btn block" data-act="tool" data-t="upscale">${icon('expand')}Upscale 4× (HD)</button>
            <button type="button" class="btn block" data-act="tool" data-t="removebg">${icon('cut')}Remove background</button>
          </div>
          <p class="muted" style="font-size:12.5px;margin-top:12px">Results are saved to My Creations automatically.</p>` : `
        <label class="f" for="prompt">${isVid ? 'Video prompt' : 'Prompt'}</label>
        <textarea id="prompt" class="input" maxlength="2000" placeholder="${isVid ? 'Describe the scene and the motion…' : 'Describe what you want to see…'}">${esc(S.prompt)}</textarea>
        <div class="row" style="margin-top:8px"><button type="button" class="btn sm" data-act="surprise" data-target="prompt" data-kind="${kind}">${icon('sparkle')}Suggest a prompt</button></div>
        <div class="chips" style="margin-top:8px">${ideasRow(isVid ? VID_IDEAS : IMG_IDEAS, 'prompt')}</div>
        ${isVid ? '' : `<label class="f" for="neg">Negative prompt <span style="font-weight:400">(what to avoid)</span></label>
        <input id="neg" class="input" maxlength="500" placeholder="blurry, low quality, extra fingers, watermark" value="${esc(S.neg)}">`}
        <label class="f">${isVid ? 'Video style' : 'Image style'}</label>${chipRow('style', styles, S.style, v => v === '3d' ? '3D' : v)}
        <label class="f">${isVid ? 'Video effects' : 'Photo effects'} <span style="font-weight:400">(optional)</span></label>
        <div class="chips">${fxList.map(([n]) => `<button type="button" class="chip ${S.fx.has(n) ? 'on' : ''}" data-chip="fx" data-v="${esc(n)}">${esc(n)}</button>`).join('')}</div>
        ${isVid ? `<label class="f">Duration</label>${chipRow('duration', AR.OPTS.durations, S.duration, v => v + ' sec')}` : ''}
        <label class="f">Aspect ratio</label>${chipRow('aspect', aspects, S.aspect, v => v === 'match' ? 'Match input' : v)}
        ${isVid && m === 'img2video' ? '<p class="muted" style="font-size:12.5px;margin-top:8px">With an image, the video follows your image’s proportions.</p>' : ''}
        <button type="button" id="go" class="btn primary glow block" style="margin-top:20px;padding:14px" data-act="generate">${icon('sparkle')}Generate ${isVid ? 'Video' : 'Image'}</button>
        <p class="muted" style="font-size:12.5px;text-align:center;margin-top:8px" id="qnote">${AR.state.quota ? `${AR.state.quota.remaining} generation${AR.state.quota.remaining === 1 ? '' : 's'} left today` : 'Log in to generate'}</p>`}`;
      };

      const render = () => {
        $('#panel').innerHTML = panelHtml();
        const ta = $('#prompt'); if (ta) ta.addEventListener('input', () => (S.prompt = ta.value));
        const ng = $('#neg'); if (ng) ng.addEventListener('input', () => (S.neg = ng.value));
      };

      const setPreview = html => ($('#preview').innerHTML = html);

      const showProgress = g => {
        const pr = g ? Math.max(g.progress || 0, 4) : 3;
        if (!$('#pbar')) {
          setPreview(`<div class="progress"><div class="spinner"></div><h3 id="ptitle" style="margin-bottom:6px">${isVid ? 'Creating your video…' : 'Creating your image…'}</h3>
            <p class="muted" style="margin-bottom:14px">${isVid ? 'Videos usually take 1–3 minutes. You can keep this tab open.' : 'This usually takes 5–30 seconds.'}</p>
            <div class="bar"><i id="pbar"></i></div><p class="muted" style="margin-top:8px;font-size:13px" id="ppct"></p></div>`);
        }
        $('#pbar').style.width = pr + '%';
        $('#ppct').textContent = pr + '%';
      };

      const showResult = g => {
        const m = g.result; AR.remember([m]);
        setPreview(`<div style="width:100%">
          ${isVid ? `<video src="${esc(m.url)}" controls autoplay loop playsinline></video>` : `<img src="${esc(m.url)}" alt="${esc(m.prompt)}">`}
          <div class="actions">
            <button class="btn primary sm" data-act="dlres" data-id="${m.id}">${icon('download')}Download ${isVid ? 'MP4' : 'HD'}</button>
            <button class="btn sm" data-act="shareres" data-id="${m.id}">${icon('share')}Share</button>
            <button class="btn sm" data-act="view" data-id="${m.id}">${icon('layers')}More options</button>
            ${isVid ? '' : `<button class="btn sm" data-act="animate" data-id="${m.id}">${icon('video')}Animate</button>`}
          </div>
          <p class="muted" style="margin-top:12px;font-size:13px">${icon('check', '').replace('<svg', '<svg style="width:14px;height:14px;vertical-align:-2px;color:#34d399"')} Saved to <a href="#/creations" style="color:var(--cyan)">My Creations</a></p></div>`);
      };

      const showError = msg => setPreview(`<div style="max-width:420px"><div class="alert err" style="margin-bottom:14px">${esc(msg)}</div><button class="btn" data-act="generate">Try again</button></div>`);

      const run = AR.safe(async (type, body) => {
        if (S.busy) return;
        if (!AR.requireLogin('Log in to start creating.')) return;
        S.busy = true; const go = $('#go'); if (go) go.disabled = true;
        showProgress(null);
        try {
          const g = await AR.runJob(type, body, showProgress);
          showResult(g);
          const qn = $('#qnote'); if (qn && AR.state.quota) qn.textContent = `${AR.state.quota.remaining} generations left today`;
        } catch (e) { showError(e.message); }
        finally { S.busy = false; const go2 = $('#go'); if (go2) go2.disabled = false; }
      });

      /* actions scoped to this page */
      const A = AR.acts;
      A.mode = t => { S.mode = t.dataset.m; S.aspect = isVid ? S.aspect : (S.mode === 'img2img' ? 'match' : '1:1'); render(); };
      A.pickref = async () => { const m = await AR.pickImage(); if (m) { S.ref = m; render(); } };
      A.tool = t => { if (!S.ref) return AR.toast('Choose an image first.', 'err'); AR.runTool(t.dataset.t, S.ref.id); };
      A.generate = () => {
        const fx = fxList.filter(([n]) => S.fx.has(n)).map(([, p]) => p).join(', ');
        const prompt = (S.prompt.trim() + (fx ? ', ' + fx : '')).trim();
        if (S.prompt.trim().length < 3) return AR.toast('Please enter a prompt.', 'err');
        if ((S.mode === 'img2img' || S.mode === 'img2video') && !S.ref) return AR.toast('Choose a reference image first.', 'err');
        run(S.mode, { prompt, negative_prompt: S.neg, style: S.style, aspect: S.aspect, duration: S.duration, media_id: S.ref ? S.ref.id : undefined });
      };
      A.dlres = t => AR.download(t.dataset.id);
      A.shareres = AR.safe(async t => { const r = await AR.api(`/media/${t.dataset.id}/share`, { method: 'POST' }); AR.copy(r.link); });
      A.animate = t => { location.hash = '#/video?mode=img2video&ref=' + t.dataset.id; };

      AR.after = async app => {
        render();
        $('.gen', app).addEventListener('click', e => {
          const c = e.target.closest('[data-chip]'); if (!c) return;
          const n = c.dataset.chip, v = c.dataset.v;
          if (n === 'fx') { S.fx.has(v) ? S.fx.delete(v) : S.fx.add(v); c.classList.toggle('on'); return; }
          S[n] = n === 'duration' ? Number(v) : v;
          $$(`[data-chip="${n}"]`, app).forEach(b => b.classList.toggle('on', b === c));
        });
        if (q.ref && AR.state.user) {
          try { const r = await AR.api('/media/' + Number(q.ref)); S.ref = r.item; AR.remember([r.item]); render(); } catch { /* ignore */ }
        }
        if (AR.state.user && !AR.state.quota) { try { AR.state.quota = await AR.api('/generate/quota'); render(); } catch { /* ignore */ } }
      };

      return `
        <h1 class="page-title">${isVid ? 'AI <span class="grad-text">Video</span> Generator' : 'AI <span class="grad-text">Photo</span> Generator'}</h1>
        <p class="page-sub">${isVid ? 'Turn words or images into cinematic video.' : 'Create from text, transform your photos, or enhance them in one click.'}</p>
        ${AR.state.cfg.aiReady === false ? `<div class="alert warn" style="margin-bottom:16px">AI generation isn’t configured on this server yet – the admin needs to add the provider API key.</div>` : ''}
        <div class="gen">
          <div class="card panel" id="panel">${panelHtml()}</div>
          <div class="card preview" id="preview">${previewShell(kind)}</div>
        </div>`;
    };
  }

  AR.pages['/photo'] = makeGenerator('photo');
  AR.pages['/video'] = makeGenerator('video');
})();
