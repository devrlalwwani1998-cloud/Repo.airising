/* AI RISING – core: state, API, UI helpers, router */
(function () {
  const AR = (window.AR = { state: { user: null, quota: null, cfg: {}, opts: null }, pages: {}, acts: {}, cache: new Map() });

  /* ---------- utils ---------- */
  AR.esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  AR.$ = (sel, el = document) => el.querySelector(sel);
  AR.$$ = (sel, el = document) => [...el.querySelectorAll(sel)];
  AR.fmtSize = b => (b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');
  AR.fmtDate = s => (s ? new Date(s.replace(' ', 'T') + 'Z').toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '–');
  AR.sleep = ms => new Promise(r => setTimeout(r, ms));

  const P = {
    home: 'M3 11l9-8 9 8v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z',
    photo: 'M4 5h16a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V6a1 1 0 011-1zm0 12l5-6 4 5 3-3 4 4M9 9.5a1.5 1.5 0 100-.01',
    video: 'M4 6h11a1 1 0 011 1v10a1 1 0 01-1 1H4a1 1 0 01-1-1V7a1 1 0 011-1zm13 4l4-2v8l-4-2z',
    gallery: 'M4 4h7v7H4zm9 0h7v7h-7zM4 13h7v7H4zm9 0h7v7h-7z',
    sparkle: 'M12 2l2.2 6.3L21 10l-6.8 1.7L12 18l-2.2-6.3L3 10l6.8-1.7zM19 16l.9 2.1L22 19l-2.1.9L19 22l-.9-2.1L16 19l2.1-.9z',
    heart: 'M12 21s-8-5.4-8-11a5 5 0 019-3 5 5 0 019 3c0 5.6-10 11-10 11z',
    user: 'M12 12a4 4 0 100-8 4 4 0 000 8zm-8 9a8 8 0 0116 0',
    upload: 'M12 16V4m0 0L7 9m5-5l5 5M4 16v3a1 1 0 001 1h14a1 1 0 001-1v-3',
    download: 'M12 4v12m0 0l-5-5m5 5l5-5M4 20h16',
    trash: 'M4 7h16M10 11v6m4-6v6M6 7l1 13h10l1-13M9 7V4h6v3',
    share: 'M12 3v12m0-12L8 7m4-4l4 4M5 12v7a1 1 0 001 1h12a1 1 0 001-1v-7',
    x: 'M6 6l12 12M18 6L6 18',
    wand: 'M15 4l5 5L8 21l-5-5zM14 7l3 3M19 2v3m1.5-1.5h-3',
    expand: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5',
    cut: 'M6 6a3 3 0 100 .01M6 18a3 3 0 100 .01M8.5 8l11 9M8.5 16l11-9',
    folder: 'M3 6a1 1 0 011-1h5l2 2h9a1 1 0 011 1v10a1 1 0 01-1 1H4a1 1 0 01-1-1z',
    shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z',
    plus: 'M12 5v14M5 12h14',
    check: 'M5 12l5 5L20 7',
    play: 'M7 4l13 8-13 8z',
    star: 'M12 3l2.7 5.8 6.3.8-4.6 4.3 1.2 6.3L12 17l-5.6 3.2 1.2-6.3L3 9.6l6.3-.8z',
    logout: 'M10 4H5a1 1 0 00-1 1v14a1 1 0 001 1h5M15 8l4 4-4 4M19 12H9',
    layers: 'M12 3l9 5-9 5-9-5zM3 13l9 5 9-5'
  };
  AR.icon = (n, cls = '') => `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${P[n] || ''}"/></svg>`;
  AR.logoSvg = `<svg viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#22d3ee"/></linearGradient></defs><path d="M32 6l7 18 18 8-18 8-7 18-7-18-18-8 18-8z" fill="url(#lg)"/></svg>`;

  /* ---------- toast ---------- */
  AR.toast = (msg, type = '') => {
    const el = document.createElement('div');
    el.className = 'toast ' + type; el.textContent = msg;
    AR.$('#toasts').appendChild(el);
    setTimeout(() => el.remove(), type === 'err' ? 6000 : 3200);
  };

  /* ---------- API ---------- */
  AR.api = async (path, opts = {}) => {
    const o = { method: opts.method || 'GET', credentials: 'same-origin', headers: {} };
    if (opts.body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(opts.body); }
    let res, data = {};
    try { res = await fetch('/api' + path, o); } catch { throw new Error('Network error. Check your connection and try again.'); }
    try { data = await res.json(); } catch { /* empty */ }
    if (!res.ok) {
      if (res.status === 401 && AR.state.user) { AR.state.user = null; AR.layout(); }
      const e = new Error(data.error || `Request failed (${res.status})`); e.status = res.status; throw e;
    }
    return data;
  };
  AR.safe = fn => async (...a) => { try { return await fn(...a); } catch (e) { AR.toast(e.message, 'err'); } };

  /* ---------- modal ---------- */
  AR.modal = (html, { wide = false, onClose } = {}) => {
    const root = AR.$('#modal-root');
    const back = document.createElement('div');
    back.className = 'modal-back';
    back.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">${html}</div>`;
    const close = () => { back.remove(); document.removeEventListener('keydown', esc); onClose && onClose(); };
    const esc = e => { if (e.key === 'Escape') close(); };
    back.addEventListener('mousedown', e => { if (e.target === back) close(); });
    back.addEventListener('click', e => { if (e.target.closest('[data-close]')) close(); });
    document.addEventListener('keydown', esc);
    root.appendChild(back);
    return { el: AR.$('.modal', back), close };
  };

  /* ---------- delegated actions ---------- */
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-act]');
    if (!t) return;
    const fn = AR.acts[t.dataset.act];
    if (fn) { e.preventDefault(); e.stopPropagation(); AR.safe(fn)(t, e); }
  });

  AR.requireLogin = (msg) => {
    if (AR.state.user) return true;
    AR.toast(msg || 'Please log in or sign up to continue.');
    location.hash = '#/login?next=' + encodeURIComponent(location.hash.slice(1) || '/');
    return false;
  };

  /* ---------- layout ---------- */
  const NAV = [['/', 'Home', 'home'], ['/photo', 'AI Photo', 'photo'], ['/video', 'AI Video', 'video'], ['/gallery', 'Gallery', 'gallery'], ['/creations', 'My Creations', 'sparkle']];
  AR.layout = () => {
    const u = AR.state.user, cur = AR.route.path;
    const active = p => (p === '/' ? cur === '/' : cur.startsWith(p)) ? 'active' : '';
    const q = AR.state.quota;
    AR.$('#topbar').innerHTML = `
      <a href="#/" class="logo" aria-label="AI RISING home">${AR.logoSvg}<span>AI <b>RISING</b></span></a>
      <nav class="nav" aria-label="Main">${NAV.map(([p, l]) => `<a href="#${p}" class="${active(p)}">${l}</a>`).join('')}
        ${u && u.role === 'admin' ? `<a href="#/admin" class="${active('/admin')}">Admin</a>` : ''}</nav>
      <div class="top-right">
        ${u ? `${q ? `<span class="quota-pill" title="Generations used today">${q.used}/${q.limit} today</span>` : ''}
          ${u.plan === 'free' ? `<a class="btn sm primary" href="#/pricing">Upgrade</a>` : ''}
          <a class="avatar" href="#/profile" aria-label="Profile">${u.avatar ? `<img src="${AR.esc(u.avatar)}" alt="" referrerpolicy="no-referrer">` : AR.esc(u.name[0].toUpperCase())}</a>`
        : `<a class="btn sm" href="#/login">Login</a><a class="btn sm primary" href="#/login?mode=signup">Sign up</a>`}
      </div>`;
    AR.$('#tabbar').innerHTML = NAV.map(([p, l, ic]) => `<a href="#${p}" class="${active(p)}">${AR.icon(ic)}<span>${l.replace('My ', '')}</span></a>`).join('');
  };

  /* ---------- router ---------- */
  AR.route = { path: '/', query: {} };
  const AUTH_ONLY = ['/gallery', '/creations', '/profile', '/admin'];
  let renderToken = 0;

  AR.navigate = async () => {
    const raw = location.hash.slice(1) || '/';
    const [path, qs] = raw.split('?');
    const query = Object.fromEntries(new URLSearchParams(qs || ''));
    AR.route = { path: path.replace(/\/$/, '') || '/', query };
    const seg = '/' + (AR.route.path.split('/')[1] || '');
    const page = AR.pages[seg];
    const app = AR.$('#app');
    AR.layout();
    if (AUTH_ONLY.includes(seg) && !AR.state.user) { location.replace('#/login?next=' + encodeURIComponent(raw)); return; }
    if (seg === '/admin' && AR.state.user && AR.state.user.role !== 'admin') { location.replace('#/'); return; }
    const token = ++renderToken;
    app.innerHTML = '<div style="padding:60px 0;text-align:center"><div class="spinner"></div></div>';
    try {
      const html = await (page || AR.pages['/404'])(AR.route);
      if (token !== renderToken) return;
      if (typeof html === 'string') app.innerHTML = html;
      app.querySelector('[data-after]') && app.querySelector('[data-after]').dispatchEvent(new Event('after'));
      if (AR.after) { const f = AR.after; AR.after = null; f(app); }
      window.scrollTo({ top: 0 });
    } catch (e) {
      if (token !== renderToken) return;
      app.innerHTML = `<div class="empty"><h3>Something went wrong</h3><p>${AR.esc(e.message)}</p><p style="margin-top:14px"><a class="btn" href="#/">Back home</a></p></div>`;
    }
  };

  AR.pages['/404'] = () => `<div class="empty"><h3>Page not found</h3><p style="margin-top:14px"><a class="btn primary" href="#/">Go home</a></p></div>`;

  /* ---------- job runner (start + poll) ---------- */
  AR.runJob = async (type, body, onUpdate) => {
    const { generation, quota } = await AR.api('/generate/' + type, { method: 'POST', body });
    AR.state.quota = quota; AR.layout();
    let g = generation;
    onUpdate && onUpdate(g);
    let misses = 0;
    while (g.status === 'queued' || g.status === 'running') {
      await AR.sleep(2500);
      try {
        const r = await AR.api('/generate/job/' + g.id);
        g = r.generation; AR.state.quota = r.quota; misses = 0;
        onUpdate && onUpdate(g);
      } catch (e) { if (++misses > 5) throw e; }
    }
    AR.layout();
    if (g.status === 'failed') throw new Error(g.error || 'Generation failed.');
    return g;
  };

  /* ---------- uploads (XHR for progress) ---------- */
  const OK_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/mp4', 'video/webm', 'video/quicktime'];
  AR.validateFile = f => {
    const isVid = f.type.startsWith('video/');
    if (!OK_TYPES.includes(f.type) && !/\.(jpe?g|png|webp|gif|mp4|webm|mov)$/i.test(f.name)) return 'Unsupported format. Use JPG, PNG, WEBP, GIF, MP4, WEBM or MOV.';
    if (!isVid && f.size > 20 * 1024 * 1024) return 'Image is larger than 20 MB.';
    if (isVid && f.size > 100 * 1024 * 1024) return 'Video is larger than 100 MB.';
    if (f.size === 0) return 'File is empty.';
    return null;
  };
  AR.uploadFiles = (files, { folderId, onProgress } = {}) => new Promise((resolve, reject) => {
    const fd = new FormData();
    files.forEach(f => fd.append('files', f));
    if (folderId) fd.append('folder_id', folderId);
    const x = new XMLHttpRequest();
    x.open('POST', '/api/media/upload');
    x.withCredentials = true;
    x.upload.onprogress = e => e.lengthComputable && onProgress && onProgress(Math.round((e.loaded / e.total) * 100));
    x.onload = () => {
      let d = {}; try { d = JSON.parse(x.responseText); } catch { /* ignore */ }
      if (x.status >= 200 && x.status < 300) resolve(d); else reject(new Error(d.error || 'Upload failed.'));
    };
    x.onerror = () => reject(new Error('Network error during upload.'));
    x.send(fd);
  });

  /* ---------- media helpers ---------- */
  AR.remember = items => items.forEach(m => AR.cache.set(m.id, m));
  AR.mediaEl = (m, attrs = '') => m.kind === 'video'
    ? `<video src="${AR.esc(m.url)}#t=0.1" muted playsinline preload="metadata" ${attrs}></video>`
    : `<img src="${AR.esc(m.url)}" alt="${AR.esc(m.prompt || m.name || 'Creation')}" loading="lazy" ${attrs}>`;

  AR.tile = (m, { fav = true, sel = false, tag } = {}) => `
    <div class="tile ${sel ? 'sel' : ''}" data-act="view" data-id="${m.id}">
      ${AR.mediaEl(m)}
      ${m.kind === 'video' ? `<span class="tag">${AR.icon('play')}</span>` : tag ? `<span class="tag">${AR.esc(tag)}</span>` : ''}
      ${fav ? `<button class="fav ${m.favorite ? 'on' : ''}" data-act="fav" data-id="${m.id}" aria-label="Favorite">${AR.icon('heart')}</button>` : ''}
      <div class="cap">${AR.esc(m.prompt || m.name || '')}</div>
    </div>`;

  AR.acts.fav = async t => {
    const id = Number(t.dataset.id), m = AR.cache.get(id); if (!m) return;
    const r = await AR.api('/media/' + id, { method: 'PATCH', body: { favorite: !m.favorite } });
    AR.cache.set(id, { ...m, ...r.item });
    AR.$$(`.fav[data-id="${id}"]`).forEach(b => b.classList.toggle('on', r.item.favorite));
    if (AR.onMediaChange) AR.onMediaChange(id);
  };

  AR.download = id => { const a = document.createElement('a'); a.href = `/api/media/${id}/download`; a.download = ''; document.body.appendChild(a); a.click(); a.remove(); };

  AR.copy = async text => {
    try { await navigator.clipboard.writeText(text); AR.toast('Link copied!', 'ok'); }
    catch { window.prompt('Copy this link:', text); }
  };

  /* viewer with every action */
  AR.view = async id => {
    const m = AR.cache.get(Number(id)); if (!m) return;
    const own = !m.author;
    const isImg = m.kind === 'image';
    const body = () => `
      <div class="modal-head"><h3>${m.kind === 'video' ? 'Video' : 'Photo'}</h3><button class="btn icon" data-close aria-label="Close">${AR.icon('x')}</button></div>
      <div class="viewer">
        ${m.kind === 'video' ? `<video src="${AR.esc(m.url)}" controls autoplay loop playsinline></video>` : `<img src="${AR.esc(m.url)}" alt="">`}
        ${m.prompt ? `<p class="muted" style="font-size:13.5px">“${AR.esc(m.prompt)}”${m.style ? ` · <span class="badge">${AR.esc(m.style)}</span>` : ''}${m.author ? ` · by ${AR.esc(m.author)}` : ''}</p>` : ''}
        ${own ? `<div class="actions" style="margin:0">
          <button class="btn sm primary" data-v="dl">${AR.icon('download')}Download</button>
          <button class="btn sm" data-v="fav">${AR.icon('heart')}${m.favorite ? 'Unfavorite' : 'Favorite'}</button>
          <button class="btn sm" data-v="share">${AR.icon('share')}Share link</button>
          ${m.source === 'generated' ? `<button class="btn sm" data-v="pub">${AR.icon('star')}${m.is_public ? 'Unpublish' : 'Publish to Trending'}</button>` : ''}
          ${isImg ? `<button class="btn sm" data-v="photo">${AR.icon('photo')}Use in AI Photo</button><button class="btn sm" data-v="video">${AR.icon('video')}Animate</button>
          <button class="btn sm" data-v="enhance">${AR.icon('wand')}Enhance</button><button class="btn sm" data-v="upscale">${AR.icon('expand')}Upscale 4×</button><button class="btn sm" data-v="removebg">${AR.icon('cut')}Remove BG</button>` : ''}
          <button class="btn sm danger" data-v="del">${AR.icon('trash')}Delete</button></div>` : ''}
      </div>`;
    const { el, close } = AR.modal(body(), { wide: true });
    el.addEventListener('click', AR.safe(async e => {
      const b = e.target.closest('[data-v]'); if (!b) return;
      const v = b.dataset.v;
      if (v === 'dl') AR.download(m.id);
      else if (v === 'fav') { await AR.acts.fav({ dataset: { id: m.id } }); close(); AR.view(m.id); }
      else if (v === 'share') { const r = await AR.api(`/media/${m.id}/share`, { method: 'POST' }); AR.copy(r.link); }
      else if (v === 'pub') { const r = await AR.api('/media/' + m.id, { method: 'PATCH', body: { is_public: !m.is_public } }); AR.cache.set(m.id, { ...m, ...r.item }); AR.toast(r.item.is_public ? 'Published to Trending' : 'Removed from Trending', 'ok'); close(); AR.view(m.id); }
      else if (v === 'photo') { close(); location.hash = '#/photo?mode=img2img&ref=' + m.id; }
      else if (v === 'video') { close(); location.hash = '#/video?mode=img2video&ref=' + m.id; }
      else if (v === 'del') {
        if (!confirm('Delete this file permanently?')) return;
        await AR.api('/media/' + m.id, { method: 'DELETE' }); AR.cache.delete(m.id); close(); AR.toast('Deleted', 'ok');
        AR.onMediaChange && AR.onMediaChange(m.id, true);
      } else if (['enhance', 'upscale', 'removebg'].includes(v)) { close(); AR.runTool(v, m.id); }
    }));
  };
  AR.acts.view = t => AR.view(t.dataset.id);

  const TOOL_LABEL = { enhance: 'Enhancing your photo…', upscale: 'Upscaling to HD…', removebg: 'Removing background…' };
  AR.runTool = async (type, mediaId) => {
    if (!AR.requireLogin()) return;
    const { el, close } = AR.modal(`<div style="text-align:center;padding:20px 0"><div class="spinner"></div><p id="tl">${TOOL_LABEL[type]}</p>
      <div class="progress" style="margin-top:14px"><div class="bar"><i id="tb"></i></div></div></div>`);
    try {
      const g = await AR.runJob(type, { media_id: mediaId }, g => { AR.$('#tb', el).style.width = Math.max(g.progress, 5) + '%'; });
      close();
      AR.remember([g.result]); AR.toast('Done! Saved to My Creations.', 'ok'); AR.view(g.result.id);
    } catch (e) { close(); AR.toast(e.message, 'err'); }
  };

  /* picker: choose / upload a reference image */
  AR.pickImage = () => new Promise(resolve => {
    if (!AR.requireLogin()) return resolve(null);
    let done = false;
    const finish = v => { if (!done) { done = true; resolve(v); } };
    const { el, close } = AR.modal(`
      <div class="modal-head"><h3>Choose an image</h3><button class="btn icon" data-close aria-label="Close">${AR.icon('x')}</button></div>
      <label class="btn primary block" style="margin-bottom:14px">${AR.icon('upload')}Upload from phone / computer
        <input type="file" id="pk-file" accept="image/*" hidden></label>
      <div id="pk-grid" class="grid"><div class="muted">Loading…</div></div>`, { onClose: () => finish(null), wide: true });
    AR.api('/media?kind=image&limit=60').then(r => {
      AR.remember(r.items);
      AR.$('#pk-grid', el).innerHTML = r.items.length ? r.items.map(m => `<div class="tile" data-pick="${m.id}">${AR.mediaEl(m)}</div>`).join('')
        : '<div class="empty" style="grid-column:1/-1">No images yet – upload one above.</div>';
    }).catch(e => { AR.$('#pk-grid', el).innerHTML = `<div class="alert err" style="grid-column:1/-1">${AR.esc(e.message)}</div>`; });
    el.addEventListener('click', e => { const t = e.target.closest('[data-pick]'); if (t) { finish(AR.cache.get(Number(t.dataset.pick))); close(); } });
    AR.$('#pk-file', el).addEventListener('change', AR.safe(async e => {
      const f = e.target.files[0]; if (!f) return;
      const bad = AR.validateFile(f); if (bad || !f.type.startsWith('image/')) return AR.toast(bad || 'Please choose an image file.', 'err');
      AR.toast('Uploading…');
      const r = await AR.uploadFiles([f]);
      if (r.saved && r.saved[0]) { AR.remember(r.saved); finish(r.saved[0]); close(); } else AR.toast((r.rejected[0] || {}).reason || 'Upload failed', 'err');
    }));
  });

  AR.loadOpts = async () => { if (!AR.state.opts && AR.state.user) AR.state.opts = await AR.api('/generate/options'); return AR.state.opts; };
})();
