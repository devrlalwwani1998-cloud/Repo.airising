/* Login / signup / Google, profile, pricing */
(function () {
  const { esc, icon, $ } = AR;

  const afterAuth = (r) => {
    AR.state.user = r.user; AR.state.quota = r.quota || null; AR.layout();
    const next = AR.route.query.next; location.hash = next ? decodeURIComponent(next) : '#/';
    AR.toast(`Welcome, ${r.user.name.split(' ')[0]}!`, 'ok');
  };

  let gsiPromise = null;
  const loadGsi = () => gsiPromise || (gsiPromise = new Promise((res, rej) => {
    const s = document.createElement('script'); s.src = 'https://accounts.google.com/gsi/client'; s.async = true;
    s.onload = res; s.onerror = () => rej(new Error('Could not load Google sign-in.')); document.head.appendChild(s);
  }));

  AR.pages['/login'] = route => {
    if (AR.state.user) { location.replace('#/'); return ''; }
    let mode = route.query.mode === 'signup' ? 'signup' : 'login';
    const form = () => `
      <form id="authform" novalidate>
        ${mode === 'signup' ? `<label class="f" for="name">Name</label><input id="name" class="input" autocomplete="name" required>` : ''}
        <label class="f" for="email">Email</label><input id="email" type="email" class="input" autocomplete="email" required>
        <label class="f" for="pw">Password ${mode === 'signup' ? '<span style="font-weight:400">(min 8 characters)</span>' : ''}</label>
        <input id="pw" type="password" class="input" autocomplete="${mode === 'signup' ? 'new-password' : 'current-password'}" required>
        <div id="aerr" class="alert err" hidden style="margin-top:14px"></div>
        <button class="btn primary block" style="margin-top:18px;padding:13px" type="submit">${mode === 'signup' ? 'Create account' : 'Log in'}</button>
      </form>`;
    const draw = () => {
      $('#authbox').innerHTML = `
        <div class="seg" style="width:100%;display:flex;margin-bottom:6px"><button style="flex:1" class="${mode === 'login' ? 'on' : ''}" data-act="amode" data-m="login">Log in</button><button style="flex:1" class="${mode === 'signup' ? 'on' : ''}" data-act="amode" data-m="signup">Sign up</button></div>
        ${form()}
        <div id="gwrap" ${AR.state.cfg.googleClientId ? '' : 'hidden'}><div class="divider">or</div><div id="gbtn" style="display:flex;justify-content:center;min-height:44px"></div></div>`;
      $('#authform').addEventListener('submit', submit);
      if (AR.state.cfg.googleClientId) renderGoogle();
    };
    const submit = async e => {
      e.preventDefault();
      const err = $('#aerr'), btn = $('#authform button[type=submit]'); err.hidden = true; btn.disabled = true;
      try {
        const body = { email: $('#email').value, password: $('#pw').value };
        if (mode === 'signup') body.name = $('#name').value;
        afterAuth(await AR.api('/auth/' + mode, { method: 'POST', body }));
      } catch (ex) { err.textContent = ex.message; err.hidden = false; btn.disabled = false; }
    };
    const renderGoogle = async () => {
      try {
        await loadGsi();
        google.accounts.id.initialize({
          client_id: AR.state.cfg.googleClientId,
          callback: AR.safe(async resp => afterAuth(await AR.api('/auth/google', { method: 'POST', body: { credential: resp.credential } })))
        });
        google.accounts.id.renderButton($('#gbtn'), { theme: 'filled_black', size: 'large', shape: 'pill', text: 'continue_with', width: 300 });
      } catch (e) { $('#gwrap').hidden = true; }
    };
    AR.acts.amode = t => { mode = t.dataset.m; draw(); };
    AR.after = () => draw();
    return `<div class="auth card"><div style="text-align:center;margin-bottom:10px"><h1 style="font-size:26px">Welcome to <span class="grad-text">AI RISING</span></h1>
      <p class="muted">Create Beyond Imagination.</p></div><div id="authbox"></div></div>`;
  };

  AR.pages['/profile'] = async () => {
    const u = AR.state.user, q = AR.state.quota || {};
    AR.acts.logout = async () => { await AR.api('/auth/logout', { method: 'POST' }); AR.state.user = null; AR.state.quota = null; AR.layout(); location.hash = '#/'; };
    AR.acts.saveprofile = async () => {
      const r = await AR.api('/auth/me', { method: 'PATCH', body: { name: $('#pname').value } });
      AR.state.user = r.user; AR.layout(); AR.toast('Profile updated', 'ok');
    };
    AR.acts.savepw = async () => {
      await AR.api('/auth/password', { method: 'POST', body: { current_password: $('#pw0') ? $('#pw0').value : '', new_password: $('#pw1').value } });
      AR.toast('Password updated', 'ok'); if ($('#pw0')) $('#pw0').value = ''; $('#pw1').value = '';
    };
    AR.acts.delacct = async () => {
      if (!confirm('Permanently delete your account and ALL your files? This cannot be undone.')) return;
      await AR.api('/auth/me', { method: 'DELETE', body: { password: $('#delpw') ? $('#delpw').value : '' } });
      AR.state.user = null; AR.layout(); location.hash = '#/'; AR.toast('Account deleted');
    };
    return `
      <h1 class="page-title">My <span class="grad-text">Profile</span></h1><p class="page-sub">Manage your account and security.</p>
      <div class="gen" style="max-width:900px">
        <div class="card"><div class="row"><div class="avatar" style="width:56px;height:56px;font-size:22px;cursor:default">${u.avatar ? `<img src="${esc(u.avatar)}" alt="" referrerpolicy="no-referrer">` : esc(u.name[0].toUpperCase())}</div>
          <div><b>${esc(u.name)}</b><div class="muted" style="font-size:13px">${esc(u.email)}</div></div></div>
          <div class="row" style="margin:16px 0"><span class="badge ${u.plan === 'premium' ? 'ok' : ''}">${u.plan === 'premium' ? 'Premium' : 'Free plan'}</span>${u.role === 'admin' ? '<span class="badge warn">Admin</span>' : ''}
            <span class="muted" style="font-size:13px">${q.used ?? 0}/${q.limit ?? '–'} generations used today</span></div>
          ${u.plan === 'free' ? `<a class="btn primary block" href="#/pricing">${icon('star')}Upgrade to Premium</a>` : ''}
          <button class="btn block" style="margin-top:10px" data-act="logout">${icon('logout')}Log out</button></div>
        <div class="card">
          <h3>Account details</h3><label class="f" for="pname">Name</label><input id="pname" class="input" value="${esc(u.name)}" maxlength="60">
          <button class="btn primary" style="margin-top:12px" data-act="saveprofile">Save</button>
          <h3 style="margin-top:28px">${u.hasPassword ? 'Change password' : 'Set a password'}</h3>
          ${u.hasPassword ? `<label class="f" for="pw0">Current password</label><input id="pw0" type="password" class="input" autocomplete="current-password">` : '<p class="muted" style="font-size:13px">You signed in with Google. Set a password to also log in with email.</p>'}
          <label class="f" for="pw1">New password (min 8)</label><input id="pw1" type="password" class="input" autocomplete="new-password">
          <button class="btn" style="margin-top:12px" data-act="savepw">Update password</button>
          <h3 style="margin-top:28px;color:var(--err)">Danger zone</h3>
          ${u.hasPassword ? `<label class="f" for="delpw">Confirm password</label><input id="delpw" type="password" class="input">` : ''}
          <button class="btn danger" style="margin-top:12px" data-act="delacct">${icon('trash')}Delete my account</button></div>
      </div>`;
  };

  AR.pages['/pricing'] = () => {
    const L = AR.state.cfg.limits || { free: 5, premium: 100 };
    const u = AR.state.user, link = AR.state.cfg.paymentLink;
    AR.acts.upgrade = () => {
      if (!AR.requireLogin('Log in first to upgrade.')) return;
      if (link) window.open(link, '_blank', 'noopener');
      else AR.toast('Online checkout is not enabled yet. Contact the site admin to activate Premium.', 'err');
    };
    return `
      <div style="text-align:center;margin-bottom:26px"><h1 class="page-title">Simple <span class="grad-text">plans</span></h1><p class="page-sub">Start free. Upgrade when you need more power.</p></div>
      <div class="plans" style="max-width:820px;margin:0 auto">
        <div class="plan"><h3>Free</h3><div class="price">$0</div><p class="muted">For trying things out</p>
          <ul><li>${L.free} generations per day</li><li>Photos &amp; short videos</li><li>Enhance, upscale, remove background</li><li>Private gallery &amp; folders</li></ul>
          ${u && u.plan === 'free' ? '<button class="btn block" disabled>Current plan</button>' : u ? '' : '<a class="btn block" href="#/login?mode=signup">Get started</a>'}</div>
        <div class="plan pro"><span class="badge">Most popular</span><h3 style="margin-top:8px">Premium</h3><div class="price">Pro</div><p class="muted">For creators &amp; businesses</p>
          <ul><li>${L.premium} generations per day</li><li>Photos, videos &amp; every AI tool</li><li>Everything in Free</li></ul>
          ${u && u.plan === 'premium' ? '<button class="btn block" disabled>Your current plan</button>' : '<button class="btn primary glow block" data-act="upgrade">Upgrade to Premium</button>'}</div>
      </div>`;
  };
})();
