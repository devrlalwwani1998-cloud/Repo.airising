/* boot */
(async function () {
  try {
    const [cfg, me] = await Promise.all([AR.api('/auth/config'), AR.api('/auth/me')]);
    AR.state.cfg = cfg;
    AR.state.user = me.user; AR.state.quota = me.quota || null;
  } catch (e) {
    AR.$('#app').innerHTML = `<div class="empty"><h3>Can’t reach the server</h3><p>${AR.esc(e.message)}</p></div>`;
  }
  window.addEventListener('hashchange', AR.navigate);
  AR.navigate();
})();
