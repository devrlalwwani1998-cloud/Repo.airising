/* Gallery (uploads), My Creations, public share page */
(function () {
  const { esc, icon, $, $$ } = AR;

  const rowActions = (m, extra = '') => `<div class="row" style="gap:6px;margin-top:6px;justify-content:center">
    <button class="btn sm icon" title="Download" data-act="dlres" data-id="${m.id}">${icon('download')}</button>
    <button class="btn sm icon" title="Share link" data-act="shareres" data-id="${m.id}">${icon('share')}</button>
    ${extra}
    <button class="btn sm icon danger" title="Delete" data-act="delmedia" data-id="${m.id}">${icon('trash')}</button></div>`;

  AR.acts.dlres = t => AR.download(t.dataset.id);
  AR.acts.shareres = async t => { const r = await AR.api(`/media/${t.dataset.id}/share`, { method: 'POST' }); AR.copy(r.link); };
  AR.acts.delmedia = async t => {
    if (!confirm('Delete this file permanently?')) return;
    const id = Number(t.dataset.id);
    await AR.api('/media/' + id, { method: 'DELETE' });
    AR.cache.delete(id); AR.toast('Deleted', 'ok');
    AR.onMediaChange && AR.onMediaChange(id, true);
  };

  /* ================= GALLERY ================= */
  AR.pages['/gallery'] = () => {
    const S = { folder: 'all', kind: '', folders: [], items: [] };

    const load = async () => {
      const qs = new URLSearchParams({ source: 'upload', limit: 200 });
      if (S.folder !== 'all') qs.set('folder', S.folder);
      if (S.kind) qs.set('kind', S.kind);
      const [fl, it] = await Promise.all([AR.api('/media/folders'), AR.api('/media?' + qs)]);
      S.folders = fl.folders; S.items = it.items; AR.remember(it.items);
      draw();
    };

    const draw = () => {
      $('#folders').innerHTML = `
        <button class="chip ${S.folder === 'all' ? 'on' : ''}" data-act="gfolder" data-f="all">All</button>
        <button class="chip ${S.folder === 'none' ? 'on' : ''}" data-act="gfolder" data-f="none">Unfiled</button>
        ${S.folders.map(f => `<button class="chip ${String(S.folder) === String(f.id) ? 'on' : ''}" data-act="gfolder" data-f="${f.id}">${icon('folder').replace('<svg', '<svg style="width:14px;height:14px;vertical-align:-2px"')} ${esc(f.name)} (${f.count})</button>`).join('')}
        <button class="chip" data-act="newfolder">+ New folder</button>
        ${!['all', 'none'].includes(S.folder) ? `<button class="chip" data-act="renfolder">Rename</button><button class="chip" data-act="delfolder" style="color:var(--err)">Delete folder</button>` : ''}`;
      $('#kinds').innerHTML = [['', 'All'], ['image', 'Images'], ['video', 'Videos']].map(([k, l]) => `<button class="${S.kind === k ? 'on' : ''}" data-act="gkind" data-k="${k}">${l}</button>`).join('');
      $('#ggrid').innerHTML = S.items.length
        ? S.items.map(m => `<div>${AR.tile(m)}${rowActions(m, m.kind === 'image' ? `<button class="btn sm icon" title="Use as AI reference" data-act="useref" data-id="${m.id}">${icon('wand')}</button>` : '')}
            <div class="row" style="justify-content:center;margin-top:4px"><button class="chip" style="padding:4px 10px;font-size:12px" data-act="move" data-id="${m.id}">${icon('folder').replace('<svg', '<svg style="width:12px;height:12px;vertical-align:-1px"')} Move</button></div></div>`).join('')
        : `<div class="empty" style="grid-column:1/-1"><h3>No uploads here yet</h3><p>Drag files onto the box above or tap it to choose from your device.</p></div>`;
    };
    AR.onMediaChange = () => load().catch(() => {});

    const A = AR.acts;
    A.gfolder = t => { S.folder = t.dataset.f; load(); };
    A.gkind = t => { S.kind = t.dataset.k; load(); };
    A.newfolder = async () => {
      const name = prompt('Folder name:'); if (!name) return;
      const r = await AR.api('/media/folders', { method: 'POST', body: { name } });
      S.folder = r.folder.id; await load();
    };
    A.renfolder = async () => {
      const f = S.folders.find(x => String(x.id) === String(S.folder)); const name = prompt('Rename folder:', f ? f.name : ''); if (!name) return;
      await AR.api('/media/folders/' + S.folder, { method: 'PATCH', body: { name } }); await load();
    };
    A.delfolder = async () => {
      if (!confirm('Delete this folder? Files inside are kept and moved to Unfiled.')) return;
      await AR.api('/media/folders/' + S.folder, { method: 'DELETE' }); S.folder = 'all'; await load();
    };
    A.move = t => {
      const id = Number(t.dataset.id);
      const { el, close } = AR.modal(`<div class="modal-head"><h3>Move to folder</h3><button class="btn icon" data-close>${icon('x')}</button></div>
        <div style="display:grid;gap:8px"><button class="btn" data-fid="">Unfiled</button>${S.folders.map(f => `<button class="btn" data-fid="${f.id}">${esc(f.name)}</button>`).join('')}</div>
        ${S.folders.length ? '' : '<p class="muted" style="margin-top:12px">Create a folder first with “+ New folder”.</p>'}`);
      el.addEventListener('click', AR.safe(async e => {
        const b = e.target.closest('[data-fid]'); if (!b) return;
        await AR.api('/media/' + id, { method: 'PATCH', body: { folder_id: b.dataset.fid || null } });
        close(); AR.toast('Moved', 'ok'); load();
      }));
    };
    A.useref = t => {
      const m = AR.cache.get(Number(t.dataset.id));
      const { el, close } = AR.modal(`<div class="modal-head"><h3>Use “${esc(m.name || 'image')}” in…</h3><button class="btn icon" data-close>${icon('x')}</button></div>
        <div style="display:grid;gap:10px"><a class="btn primary" href="#/photo?mode=img2img&ref=${m.id}" data-close>${icon('photo')}AI Photo (Image → Image)</a>
        <a class="btn" href="#/video?mode=img2video&ref=${m.id}" data-close>${icon('video')}AI Video (Image → Video)</a>
        <a class="btn" href="#/photo?mode=tools&ref=${m.id}" data-close>${icon('wand')}Enhance / Upscale / Remove BG</a></div>`);
    };

    /* upload handling */
    const queue = AR.safe(async files => {
      files = [...files]; if (!files.length) return;
      const list = $('#uplist');
      let okCount = 0;
      for (const f of files) {
        const row = document.createElement('div'); row.className = 'up-item';
        const isImg = f.type.startsWith('image/');
        row.innerHTML = `${isImg ? `<img class="thumb" src="${URL.createObjectURL(f)}" alt="">` : `<div class="thumb" style="display:grid;place-items:center">${icon('video')}</div>`}
          <div style="flex:1;min-width:0"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(f.name)} <span class="muted">· ${AR.fmtSize(f.size)}</span></div><div class="bar" style="margin-top:6px"><i></i></div></div><span class="st muted" style="font-size:12px;min-width:70px;text-align:right">Waiting</span>`;
        list.prepend(row);
        const bar = $('.bar i', row), st = $('.st', row);
        const bad = AR.validateFile(f);
        if (bad) { st.textContent = 'Rejected'; st.style.color = 'var(--err)'; row.title = bad; row.insertAdjacentHTML('beforeend', `<div class="muted" style="font-size:12px;color:var(--err);flex-basis:100%">${esc(bad)}</div>`); row.style.flexWrap = 'wrap'; bar.style.width = '0'; continue; }
        try {
          st.textContent = 'Uploading';
          const r = await AR.uploadFiles([f], { folderId: ['all', 'none'].includes(S.folder) ? null : S.folder, onProgress: p => (bar.style.width = p + '%') });
          if (r.saved && r.saved.length) { st.textContent = 'Done ✓'; st.style.color = 'var(--ok)'; bar.style.width = '100%'; okCount++; }
          else throw new Error((r.rejected[0] || {}).reason || 'Failed');
        } catch (e) { st.textContent = 'Failed'; st.style.color = 'var(--err)'; row.insertAdjacentHTML('beforeend', `<div style="font-size:12px;color:var(--err);flex-basis:100%">${esc(e.message)}</div>`); row.style.flexWrap = 'wrap'; }
      }
      if (okCount) { AR.toast(`${okCount} file${okCount > 1 ? 's' : ''} uploaded`, 'ok'); load(); }
    });

    AR.after = app => {
      const dz = $('#drop', app), inp = $('#files', app);
      dz.addEventListener('click', () => inp.click());
      dz.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); inp.click(); } });
      inp.addEventListener('change', () => { queue(inp.files); inp.value = ''; });
      ['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('over'); }));
      ['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('over'); }));
      dz.addEventListener('drop', e => queue(e.dataTransfer.files));
      load().catch(e => AR.toast(e.message, 'err'));
    };

    return `
      <h1 class="page-title">Upload <span class="grad-text">Gallery</span></h1>
      <p class="page-sub">Upload photos and videos from your phone or computer, organize them in folders, and use them as AI references.</p>
      <div class="drop" id="drop" tabindex="0" role="button" aria-label="Upload files">
        ${icon('upload')}<h3>Drag &amp; drop files here</h3><p class="muted">or tap to choose · JPG, PNG, WEBP, GIF (≤20 MB) · MP4, WEBM, MOV (≤100 MB)</p>
        <input type="file" id="files" accept="image/*,video/*" multiple hidden>
      </div>
      <div id="uplist"></div>
      <div class="sec" style="margin-top:28px"><div class="chips" id="folders"></div>
        <div class="seg" id="kinds" style="margin:14px 0"></div>
        <div class="grid" id="ggrid"><div class="spinner" style="grid-column:1/-1"></div></div></div>`;
  };

  /* ================= MY CREATIONS ================= */
  AR.pages['/creations'] = route => {
    const TABS = [['photos', 'Photos'], ['videos', 'Videos'], ['uploads', 'Uploads'], ['favorites', 'Favorites'], ['downloads', 'Downloads']];
    const tab = TABS.some(t => t[0] === route.query.tab) ? route.query.tab : 'photos';

    const load = async () => {
      const qsMap = { photos: 'source=generated&kind=image', videos: 'source=generated&kind=video', uploads: 'source=upload', favorites: 'favorite=1' };
      const grid = $('#cgrid'); if (!grid) return;
      const r = tab === 'downloads' ? await AR.api('/media/download-history') : await AR.api('/media?limit=200&' + qsMap[tab]);
      AR.remember(r.items);
      grid.innerHTML = r.items.length ? r.items.map(m => `<div>${AR.tile(m, { tag: tab === 'downloads' ? '' : '' })}
          ${tab === 'downloads' ? `<div class="muted" style="font-size:11.5px;text-align:center;margin-top:4px">Downloaded ${AR.fmtDate(m.downloaded_at)}</div>` : ''}
          ${rowActions(m, m.source === 'generated' ? `<button class="btn sm icon" title="${m.is_public ? 'Remove from Trending' : 'Publish to Trending'}" data-act="pub" data-id="${m.id}" style="${m.is_public ? 'color:var(--warn)' : ''}">${icon('star')}</button>` : '')}</div>`).join('')
        : `<div class="empty" style="grid-column:1/-1"><h3>Nothing here yet</h3><p>${tab === 'photos' ? 'Generated photos will appear here.' : tab === 'videos' ? 'Generated videos will appear here.' : tab === 'favorites' ? 'Tap the heart on any creation to add it here.' : tab === 'downloads' ? 'Files you download are listed here.' : 'Upload files in the Gallery.'}</p>
          <p style="margin-top:14px"><a class="btn primary" href="#/${tab === 'videos' ? 'video' : tab === 'uploads' ? 'gallery' : 'photo'}">${tab === 'uploads' ? 'Open Gallery' : 'Start creating'}</a></p></div>`;
    };
    AR.onMediaChange = () => load().catch(() => {});
    AR.acts.pub = async t => {
      const id = Number(t.dataset.id), m = AR.cache.get(id);
      const r = await AR.api('/media/' + id, { method: 'PATCH', body: { is_public: !m.is_public } });
      AR.cache.set(id, { ...m, ...r.item }); AR.toast(r.item.is_public ? 'Published to Trending' : 'Removed from Trending', 'ok'); load();
    };
    AR.after = () => load().catch(e => AR.toast(e.message, 'err'));
    return `
      <h1 class="page-title">My <span class="grad-text">Creations</span></h1>
      <p class="page-sub">Your private dashboard – only you can see these unless you share or publish them.</p>
      <div class="tabs">${TABS.map(([k, l]) => `<a class="${k === tab ? 'on' : ''}" href="#/creations?tab=${k}">${l}</a>`).join('')}</div>
      <div class="grid" id="cgrid"><div class="spinner" style="grid-column:1/-1"></div></div>`;
  };

  /* ================= PUBLIC SHARE ================= */
  AR.pages['/share'] = async route => {
    const token = route.path.split('/')[2];
    let item;
    try { item = (await AR.api('/media/shared/' + encodeURIComponent(token))).item; }
    catch (e) { return `<div class="empty"><h3>Link unavailable</h3><p>${esc(e.message)}</p><p style="margin-top:14px"><a class="btn primary" href="#/">Visit AI RISING</a></p></div>`; }
    return `<div style="max-width:760px;margin:0 auto" class="card"><div class="viewer">
      ${item.kind === 'video' ? `<video src="${esc(item.url)}" controls autoplay loop playsinline></video>` : `<img src="${esc(item.url)}" alt="">`}
      ${item.prompt ? `<p class="muted">“${esc(item.prompt)}”</p>` : ''}<p class="muted" style="font-size:13px">Created with AI RISING by ${esc(item.author)}</p>
      <div class="actions" style="margin:0"><a class="btn primary" href="#/photo${item.prompt ? '?prompt=' + encodeURIComponent(item.prompt) : ''}">${icon('sparkle')}Create your own</a></div></div></div>`;
  };
})();
