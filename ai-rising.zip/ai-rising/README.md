# AI RISING – Create Beyond Imagination

Full-stack AI photo & video platform: text-to-image, image-to-image, text-to-video, image-to-video, enhance / upscale / background removal, upload gallery with folders, private "My Creations", email + Google auth, admin dashboard, free/premium limits.

**Stack:** Node 20+ · Express · SQLite (better-sqlite3) · JWT cookie auth · Google Identity Services · S3-compatible storage (or local disk for dev) · Replicate **or** fal.ai · vanilla-JS SPA (no build step).

## 1. Run locally

```bash
cd ai-rising
npm install
cp .env.example .env      # then edit .env
npm start                 # http://localhost:3000
```

Minimum `.env` for real generation:

```
AI_PROVIDER=replicate
REPLICATE_API_TOKEN=r8_...        # https://replicate.com/account/api-tokens
ADMIN_EMAIL=you@example.com       # sign up with this email → you become admin
```

Without a provider key the whole site works (auth, uploads, gallery) but generating shows a clear "not configured" message – nothing is faked.

## 2. Choose the AI provider

| `AI_PROVIDER` | Key | Default models |
|---|---|---|
| `replicate` | `REPLICATE_API_TOKEN` | FLUX schnell (text→image), FLUX dev (image→image), Seedance 1 Lite (video), remove-bg, Real-ESRGAN |
| `fal` | `FAL_KEY` | fal FLUX schnell / dev, Seedance lite, rembg, ESRGAN |

Every model slug is an env var (`REPLICATE_MODEL_TEXT2IMG`, `FAL_MODEL_TEXT2VIDEO`, …). The request→model input mapping lives in `src/providers/replicate.js` and `src/providers/fal.js` (`buildInput`). If you swap in a model with different input names, adjust that one function. Model catalogs change often – check the model's API page on the provider if a call returns a validation error (it will appear in Admin → Errors).

Add another provider by creating `src/providers/<name>.js` exporting `{ name, ready, submit, poll }` and registering it in `src/providers/index.js`.

## 3. Cloud storage (production)

Local disk (`STORAGE_DRIVER=local`) is for development. For production use any S3-compatible bucket:

```
STORAGE_DRIVER=s3
S3_BUCKET=ai-rising-media
S3_REGION=auto
S3_ENDPOINT=https://<account>.r2.cloudflarestorage.com   # omit for AWS S3
S3_ACCESS_KEY_ID=...
S3_SECRET_ACCESS_KEY=...
S3_PUBLIC_BASE_URL=https://media.yourdomain.com          # public URL of the bucket / CDN
```

The bucket (or its CDN domain) must allow public **read** so images/videos display and AI providers can fetch reference images. Uploads/deletes go through the server with the secret key – it never reaches the browser.

## 4. Google sign-in

1. Google Cloud Console → APIs & Services → Credentials → **Create OAuth client ID** (Web).
2. Add your site URL (e.g. `http://localhost:3000` and `https://yourdomain.com`) to **Authorized JavaScript origins**.
3. Put the client ID in `GOOGLE_CLIENT_ID`. The "Continue with Google" button appears automatically; tokens are verified server-side.

## 5. Admin dashboard

The first account created with `ADMIN_EMAIL` becomes admin (if `ADMIN_EMAIL` is empty, the very first signup does). Open **Admin** in the top bar: overview stats, users (plan/role/limit/disable/delete), all media, generation history, API-usage counts, free/premium daily limits, error log and system status.

**Subscriptions:** plans are Free and Premium with daily limits you control. Payments are *not* built in – set `PAYMENT_LINK` to a Stripe Payment Link (or similar) so Upgrade has a destination, then switch the customer to Premium under Admin → Users. (Automating this with Stripe webhooks is the natural next step.)

## 6. Deploy

**Docker (any VPS / Fly.io / Railway):**
```bash
docker build -t ai-rising .
docker run -d -p 3000:3000 --env-file .env \
  -v ai_data:/app/data -v ai_uploads:/app/uploads ai-rising
```
**Render:** push to Git, create a Blueprint from `render.yaml`, fill the `sync:false` variables. The disk holds the SQLite DB.

Production checklist:
- `NODE_ENV=production` and a long random `JWT_SECRET` (the server refuses to start without one in production).
- Serve over HTTPS (cookies are `secure` in production) and set `PUBLIC_URL` to your https URL.
- Use `STORAGE_DRIVER=s3`; back up the `data/` volume (SQLite) – or swap in Postgres if you scale beyond one instance.
- Run a single instance (SQLite + in-process job sweeper).

## 7. How generation works

`POST /api/generate/:type` checks quota and validates input → submits to the provider → the browser polls `GET /api/generate/job/:id` (every 2.5 s) → on success the server downloads the result, stores it in your storage and records it in `media` + `generations`. A background sweeper also finishes jobs if the user closes the tab. Failures (provider errors, safety blocks, timeouts after 15 min) are logged and shown to the user in plain language.

## 8. Known limits

- Reference **videos** can be uploaded to the Gallery, but the default models only take an image as input, so videos are stored and viewable, not fed to the generator.
- Aspect ratio for image→video follows the source image (model behavior).
- No built-in payment processing or email verification / password reset (needs an email service).
- NSFW/safety filtering is whatever the provider's model enforces.

## API overview

`/api/auth/*` signup · login · google · logout · me · password · `/api/media/*` upload · list · folders · trending · download · share · `/api/generate/*` text2img · img2img · text2video · img2video · removebg · upscale · enhance · job/:id · `/api/admin/*` overview · users · media · generations · usage · limits · errors
